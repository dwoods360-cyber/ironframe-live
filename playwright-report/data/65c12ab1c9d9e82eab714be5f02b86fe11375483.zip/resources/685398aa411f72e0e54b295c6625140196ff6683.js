(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_021bf79c._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_f7682eb4._.js"
],
    source: "dynamic"
});
