(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-force-graph-2d_dist_react-force-graph-2d_mjs_442335df._.js",
  "static/chunks/_90bdced4._.js",
  "static/chunks/node_modules_1e70e981._.js"
],
    source: "dynamic"
});
