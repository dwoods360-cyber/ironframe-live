(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/components/ActiveRisks.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActiveRisks
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shield-alert.js [app-client] (ecmascript) <export default as ShieldAlert>");
;
;
function ActiveRisks() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "border-b border-slate-800 bg-slate-900/50 px-4 py-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 border-b border-slate-800 pb-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "rounded border border-dashed border-slate-700 bg-slate-950/60 p-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-2 flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs font-bold text-slate-300",
                                    children: "RISK REGISTRATION (0/10)"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ActiveRisks.tsx",
                                    lineNumber: 9,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: "rounded bg-slate-800 px-2.5 py-1 text-[10px] font-bold uppercase text-slate-200 hover:bg-slate-700",
                                    children: "+ MANUAL ENTRY"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ActiveRisks.tsx",
                                    lineNumber: 10,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/ActiveRisks.tsx",
                            lineNumber: 8,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-[10px] text-slate-500",
                            children: "Registration queue empty. Select a threat or add manual entry."
                        }, void 0, false, {
                            fileName: "[project]/app/components/ActiveRisks.tsx",
                            lineNumber: 17,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/ActiveRisks.tsx",
                    lineNumber: 7,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/ActiveRisks.tsx",
                lineNumber: 6,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-xs font-bold tracking-wide text-slate-100",
                    children: "ACTIVE RISKS (1)"
                }, void 0, false, {
                    fileName: "[project]/app/components/ActiveRisks.tsx",
                    lineNumber: 24,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/ActiveRisks.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded border border-slate-800 bg-slate-950/70 p-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-2 flex items-start justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1.5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldAlert$3e$__["ShieldAlert"], {
                                        className: "h-4 w-4 text-red-400"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ActiveRisks.tsx",
                                        lineNumber: 30,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs font-bold text-slate-100",
                                                children: "RANSOMWARE THREAT"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/ActiveRisks.tsx",
                                                lineNumber: 32,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-[10px] text-slate-400",
                                                children: "Intelligence"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/ActiveRisks.tsx",
                                                lineNumber: 33,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/ActiveRisks.tsx",
                                        lineNumber: 31,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/ActiveRisks.tsx",
                                lineNumber: 29,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-right",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] uppercase tracking-wide text-slate-400",
                                        children: "Risk Score"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ActiveRisks.tsx",
                                        lineNumber: 37,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-4xl font-extrabold text-red-500 leading-none",
                                        children: "0.63"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ActiveRisks.tsx",
                                        lineNumber: 38,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/ActiveRisks.tsx",
                                lineNumber: 36,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/ActiveRisks.tsx",
                        lineNumber: 28,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3 flex items-center justify-between rounded border border-slate-800 bg-slate-900/40 px-2 py-1.5 text-[10px] font-semibold text-slate-300",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "rounded bg-blue-500/20 px-1.5 py-0.5 text-[10px] text-blue-300",
                                children: "Intelligence"
                            }, void 0, false, {
                                fileName: "[project]/app/components/ActiveRisks.tsx",
                                lineNumber: 43,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "L: 0.9 | I: 0.7"
                            }, void 0, false, {
                                fileName: "[project]/app/components/ActiveRisks.tsx",
                                lineNumber: 44,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/ActiveRisks.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3 rounded border border-slate-800 bg-slate-900 p-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                className: "h-20 w-full resize-none bg-transparent px-1 py-1 text-[10px] text-slate-200 outline-none placeholder:text-slate-500",
                                placeholder: "Add update note..."
                            }, void 0, false, {
                                fileName: "[project]/app/components/ActiveRisks.tsx",
                                lineNumber: 48,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-end",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: "rounded bg-blue-600 px-3 py-1.5 text-[10px] font-bold uppercase tracking-wide text-white hover:bg-blue-500",
                                    children: "SUBMIT"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ActiveRisks.tsx",
                                    lineNumber: 53,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/ActiveRisks.tsx",
                                lineNumber: 52,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/ActiveRisks.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between border-t border-slate-800 pt-2 text-[10px] text-slate-400",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Registered: 2h ago"
                            }, void 0, false, {
                                fileName: "[project]/app/components/ActiveRisks.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "rounded bg-emerald-500/20 px-2 py-0.5 font-bold text-emerald-300",
                                children: "ACTIVE"
                            }, void 0, false, {
                                fileName: "[project]/app/components/ActiveRisks.tsx",
                                lineNumber: 64,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/ActiveRisks.tsx",
                        lineNumber: 62,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ActiveRisks.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/ActiveRisks.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}
_c = ActiveRisks;
var _c;
__turbopack_context__.k.register(_c, "ActiveRisks");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/hooks/useAlerts.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAlertDispatchMeta",
    ()=>getAlertDispatchMeta
]);
function getAlertDispatchMeta(alert) {
    if (alert.type === "ANOMALY") {
        return {
            label: "[ANOMALY]",
            color: "yellow",
            badgeClass: "text-amber-300",
            borderClass: "border-amber-400/80 animate-pulse shadow-[0_0_18px_rgba(251,191,36,0.3)]",
            sourceTooltip: "Source: Heuristic Monitoring"
        };
    }
    const isExternalSOC = alert.origin === "SOC_INTAKE" && alert.type === "SOC_EMAIL" && alert.isExternalSOC;
    if (isExternalSOC) {
        return {
            label: "[EXTERNAL SOC]",
            color: "purple",
            badgeClass: "text-purple-300",
            borderClass: "border-purple-500/50 shadow-[0_0_18px_rgba(168,85,247,0.25)]",
            sourceTooltip: "Source: Verified SOC Email"
        };
    }
    return {
        label: "[AGENT ALERT]",
        color: "blue",
        badgeClass: "text-blue-300",
        borderClass: "border-blue-500/40",
        sourceTooltip: "Source: Internal AI Monitoring"
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/AgentStream.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AgentStream
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye.js [app-client] (ecmascript) <export default as Eye>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shield-alert.js [app-client] (ecmascript) <export default as ShieldAlert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useAlerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useAlerts.ts [app-client] (ecmascript)");
"use client";
;
;
;
const SCORE_STYLE = (score)=>{
    if (score >= 85) {
        return "text-red-300 border-red-500/70 bg-red-500/15";
    }
    if (score >= 65) {
        return "text-amber-300 border-amber-500/70 bg-amber-500/15";
    }
    return "text-emerald-300 border-emerald-500/70 bg-emerald-500/15";
};
_c = SCORE_STYLE;
function AgentStream({ alerts, socIntakeEnabled, onApprove, onDismiss }) {
    const visibleAlerts = alerts.filter((alert)=>{
        const isCadenceDispatchConfirmation = alert.title === "CISO/LEGAL ESCALATION DISPATCH CONFIRMED";
        if (alert.type === "SOC_EMAIL" && !socIntakeEnabled && !isCadenceDispatchConfirmation) {
            return false;
        }
        return true;
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "rounded border border-slate-800 bg-slate-900/40 p-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-[10px] font-bold uppercase tracking-wide text-white",
                children: "AGENT STREAM"
            }, void 0, false, {
                fileName: "[project]/app/components/AgentStream.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1 text-[9px] uppercase tracking-wide text-slate-400",
                children: "Live Actionable Alerts"
            }, void 0, false, {
                fileName: "[project]/app/components/AgentStream.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3 max-h-80 space-y-2 overflow-y-auto pr-1",
                children: visibleAlerts.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "rounded border border-slate-800 bg-slate-950/50 p-3 text-[10px] text-slate-400",
                    children: "No active agent alerts."
                }, void 0, false, {
                    fileName: "[project]/app/components/AgentStream.tsx",
                    lineNumber: 43,
                    columnNumber: 11
                }, this) : visibleAlerts.map((alert)=>{
                    const dispatchMeta = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useAlerts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlertDispatchMeta"])({
                        type: alert.type,
                        origin: alert.origin,
                        isExternalSOC: alert.isExternalSOC
                    });
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                        className: `rounded border bg-slate-950/50 p-3 ${dispatchMeta.borderClass}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        title: dispatchMeta.sourceTooltip,
                                        className: `text-[9px] font-bold uppercase tracking-wide ${dispatchMeta.badgeClass}`,
                                        children: dispatchMeta.label
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/AgentStream.tsx",
                                        lineNumber: 57,
                                        columnNumber: 17
                                    }, this),
                                    alert.origin !== "SOC_INTAKE" && alert.sourceAgent === "IRONSIGHT" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {
                                        className: "h-3.5 w-3.5 text-blue-300"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/AgentStream.tsx",
                                        lineNumber: 64,
                                        columnNumber: 19
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldAlert$3e$__["ShieldAlert"], {
                                        className: "h-3.5 w-3.5 text-slate-400"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/AgentStream.tsx",
                                        lineNumber: 66,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[8px] font-bold uppercase tracking-wide text-slate-400",
                                        children: [
                                            "[",
                                            alert.sourceAgent,
                                            "]"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/AgentStream.tsx",
                                        lineNumber: 68,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/AgentStream.tsx",
                                lineNumber: 56,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-[10px] font-bold uppercase text-white",
                                children: alert.title
                            }, void 0, false, {
                                fileName: "[project]/app/components/AgentStream.tsx",
                                lineNumber: 70,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-[10px] text-slate-300",
                                children: alert.impact
                            }, void 0, false, {
                                fileName: "[project]/app/components/AgentStream.tsx",
                                lineNumber: 71,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-2 flex flex-wrap items-center gap-2 text-[9px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `rounded border px-2 py-0.5 font-bold uppercase ${SCORE_STYLE(alert.severityScore)}`,
                                        children: [
                                            "Severity: ",
                                            alert.severityScore,
                                            "/100"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/AgentStream.tsx",
                                        lineNumber: 74,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "rounded border border-slate-700 bg-slate-900 px-2 py-0.5 font-bold uppercase text-slate-300",
                                        children: [
                                            "Liability: $",
                                            alert.liabilityUsd.toLocaleString()
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/AgentStream.tsx",
                                        lineNumber: 77,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `rounded border px-2 py-0.5 font-bold uppercase ${alert.status === "APPROVED" ? "border-emerald-500/70 bg-emerald-500/15 text-emerald-300" : alert.status === "DISMISSED" ? "border-amber-500/70 bg-amber-500/15 text-amber-300" : "border-blue-500/70 bg-blue-500/15 text-blue-300"}`,
                                        children: alert.status
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/AgentStream.tsx",
                                        lineNumber: 80,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/AgentStream.tsx",
                                lineNumber: 73,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-3 flex gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        disabled: alert.status !== "OPEN",
                                        onClick: ()=>onApprove(alert.id),
                                        className: "rounded border border-emerald-500/70 bg-emerald-500/15 px-2 py-1 text-[9px] font-bold uppercase text-emerald-200 disabled:opacity-50",
                                        children: "APPROVE"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/AgentStream.tsx",
                                        lineNumber: 94,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        disabled: alert.status !== "OPEN",
                                        onClick: ()=>onDismiss(alert.id),
                                        className: "rounded border border-amber-500/70 bg-amber-500/15 px-2 py-1 text-[9px] font-bold uppercase text-amber-200 disabled:opacity-50",
                                        children: "DISMISS"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/AgentStream.tsx",
                                        lineNumber: 102,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/AgentStream.tsx",
                                lineNumber: 93,
                                columnNumber: 15
                            }, this)
                        ]
                    }, alert.id, true, {
                        fileName: "[project]/app/components/AgentStream.tsx",
                        lineNumber: 55,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/app/components/AgentStream.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/AgentStream.tsx",
        lineNumber: 37,
        columnNumber: 5
    }, this);
}
_c1 = AgentStream;
var _c, _c1;
__turbopack_context__.k.register(_c, "SCORE_STYLE");
__turbopack_context__.k.register(_c1, "AgentStream");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/auditLogger.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "appendAuditLog",
    ()=>appendAuditLog,
    "ensureLoginAuditEvent",
    ()=>ensureLoginAuditEvent,
    "getAuditLogSnapshot",
    ()=>getAuditLogSnapshot,
    "getAuditLogs",
    ()=>getAuditLogs,
    "hydrateAuditLogger",
    ()=>hydrateAuditLogger,
    "purgeExpiredAuditLogs",
    ()=>purgeExpiredAuditLogs,
    "subscribeAuditLogger",
    ()=>subscribeAuditLogger
]);
const AUDIT_LOG_STORAGE_KEY = "ironframe-audit-intelligence-log-v1";
const DEFAULT_USER_ID = "Dereck";
const DEFAULT_IP = "127.0.0.1";
const listeners = new Set();
let auditLogState = Object.freeze([]);
function deepFreezeLog(record) {
    return Object.freeze({
        id: record.id ?? `audit-${record.timestamp}-${Math.random().toString(36).slice(2, 8)}`,
        timestamp: record.timestamp,
        user_id: record.user_id,
        action_type: record.action_type,
        log_type: record.log_type,
        metadata_tag: record.metadata_tag,
        description: record.description,
        ip_address: record.ip_address
    });
}
function emitChange() {
    listeners.forEach((listener)=>listener());
}
function persistAuditLogState() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    window.localStorage.setItem(AUDIT_LOG_STORAGE_KEY, JSON.stringify(auditLogState));
}
function hydrateAuditLogger() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const raw = window.localStorage.getItem(AUDIT_LOG_STORAGE_KEY);
        if (!raw) {
            return;
        }
        const parsed = JSON.parse(raw);
        const safeLogs = parsed.filter((entry)=>Boolean(entry?.timestamp) && Boolean(entry?.description) && Boolean(entry?.action_type)).map((entry)=>deepFreezeLog({
                id: entry.id,
                timestamp: String(entry.timestamp),
                user_id: String(entry.user_id ?? DEFAULT_USER_ID),
                action_type: entry.action_type,
                log_type: entry.log_type ?? "APP_SYSTEM",
                metadata_tag: entry.metadata_tag ? String(entry.metadata_tag) : null,
                description: String(entry.description),
                ip_address: String(entry.ip_address ?? DEFAULT_IP)
            }));
        auditLogState = Object.freeze(safeLogs);
        emitChange();
    } catch (error) {
        console.error("AUDIT_LOGGER_HYDRATE_FAILED", error);
    }
}
function appendAuditLog(input) {
    const timestamp = input.timestamp ?? new Date().toISOString();
    const nextRecord = deepFreezeLog({
        timestamp,
        user_id: input.user_id ?? DEFAULT_USER_ID,
        action_type: input.action_type,
        log_type: input.log_type ?? "APP_SYSTEM",
        metadata_tag: input.metadata_tag ?? null,
        description: input.description,
        ip_address: input.ip_address ?? DEFAULT_IP
    });
    auditLogState = Object.freeze([
        nextRecord,
        ...auditLogState
    ].slice(0, 2000));
    persistAuditLogState();
    emitChange();
    return nextRecord;
}
function ensureLoginAuditEvent() {
    const todayKey = new Date().toISOString().slice(0, 10);
    const hasLoginToday = auditLogState.some((entry)=>entry.action_type === "LOGIN" && entry.timestamp.slice(0, 10) === todayKey);
    if (hasLoginToday) {
        return;
    }
    appendAuditLog({
        action_type: "LOGIN",
        description: "User session authenticated."
    });
}
function purgeExpiredAuditLogs(ttlDays, nowMs = Date.now()) {
    const ttlMs = ttlDays * 24 * 60 * 60 * 1000;
    const beforeCount = auditLogState.length;
    const grcBeforeCount = auditLogState.filter((entry)=>entry.log_type === "GRC").length;
    const retained = auditLogState.filter((entry)=>{
        if (entry.log_type === "GRC") {
            return true;
        }
        const ageMs = nowMs - new Date(entry.timestamp).getTime();
        return !Number.isNaN(ageMs) && ageMs <= ttlMs;
    });
    const grcAfterCount = retained.filter((entry)=>entry.log_type === "GRC").length;
    auditLogState = Object.freeze(retained);
    persistAuditLogState();
    emitChange();
    return {
        beforeCount,
        afterCount: retained.length,
        purgedCount: beforeCount - retained.length,
        grcBeforeCount,
        grcAfterCount,
        grcPurgedCount: grcBeforeCount - grcAfterCount
    };
}
function getAuditLogSnapshot() {
    return auditLogState;
}
function getAuditLogs() {
    return auditLogState.slice(0, 2000);
}
function subscribeAuditLogger(listener) {
    listeners.add(listener);
    return ()=>listeners.delete(listener);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/auditLoggerStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAuditLoggerStore",
    ()=>useAuditLoggerStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/auditLogger.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function useAuditLoggerStore() {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["subscribeAuditLogger"], __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuditLogSnapshot"], __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuditLogSnapshot"]);
}
_s(useAuditLoggerStore, "FpwL93IKMLJZuQQXefVtWynbBPQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/AuditIntelligence.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AuditIntelligence
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/auditLogger.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLoggerStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/auditLoggerStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const ACTION_LABELS = {
    LOGIN: "Login",
    CONFIG_CHANGE: "Config Change",
    EMAIL_SENT: "Email Sent",
    ALERT_DISMISSED: "Alert Dismissed"
};
function AuditIntelligence({ showRetentionBadge = false, logTypeFilter, descriptionIncludes }) {
    _s();
    const auditLogs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLoggerStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuditLoggerStore"])();
    const descriptionKeywords = descriptionIncludes?.map((keyword)=>keyword.toLowerCase()) ?? [];
    const filteredAuditLogs = auditLogs.filter((entry)=>{
        const matchesLogType = logTypeFilter ? entry.log_type === logTypeFilter : true;
        const matchesDescription = descriptionKeywords.length === 0 || descriptionKeywords.some((keyword)=>entry.description.toLowerCase().includes(keyword));
        return matchesLogType && matchesDescription;
    });
    console.log("AUDIT_INTELLIGENCE_RENDER", {
        totalLogs: auditLogs.length,
        filteredLogs: filteredAuditLogs.length,
        logTypeFilter: logTypeFilter ?? "ALL",
        descriptionIncludes: descriptionIncludes ?? []
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuditIntelligence.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hydrateAuditLogger"])();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureLoginAuditEvent"])();
            const hasTestEntry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuditLogs"])().some({
                "AuditIntelligence.useEffect.hasTestEntry": (entry)=>entry.description === "Test Audit Entry" && entry.log_type === "GRC"
            }["AuditIntelligence.useEffect.hasTestEntry"]);
            if (!hasTestEntry) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendAuditLog"])({
                    action_type: "CONFIG_CHANGE",
                    log_type: "GRC",
                    metadata_tag: "GRC_GOVERNANCE",
                    description: "Test Audit Entry"
                });
            }
        }
    }["AuditIntelligence.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuditIntelligence.useEffect": ()=>{
            console.log("AUDIT_INTELLIGENCE_HYDRATED", auditLogs);
        }
    }["AuditIntelligence.useEffect"], [
        auditLogs
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-4 text-slate-200",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-[11px] font-bold tracking-wider text-slate-400 uppercase",
                        children: "AUDIT INTELLIGENCE"
                    }, void 0, false, {
                        fileName: "[project]/app/components/AuditIntelligence.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    showRetentionBadge ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "rounded border border-blue-500/70 bg-blue-500/10 px-2 py-1 text-[9px] font-bold uppercase text-blue-200",
                        children: "Retention Policy: 7-Year Compliance Active"
                    }, void 0, false, {
                        fileName: "[project]/app/components/AuditIntelligence.tsx",
                        lineNumber: 65,
                        columnNumber: 11
                    }, this) : null
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/AuditIntelligence.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded border border-slate-800 bg-slate-900/40 px-2 py-1 text-[10px] text-slate-300",
                children: [
                    "Historical Entries: ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "font-bold text-white",
                        children: filteredAuditLogs.length
                    }, void 0, false, {
                        fileName: "[project]/app/components/AuditIntelligence.tsx",
                        lineNumber: 72,
                        columnNumber: 29
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/AuditIntelligence.tsx",
                lineNumber: 71,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-h-[460px] space-y-2 overflow-y-auto pr-1",
                children: filteredAuditLogs.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "rounded border border-slate-800 bg-slate-950/40 px-3 py-4 text-center text-[10px] text-slate-400",
                    children: "No audit actions captured yet."
                }, void 0, false, {
                    fileName: "[project]/app/components/AuditIntelligence.tsx",
                    lineNumber: 77,
                    columnNumber: 11
                }, this) : filteredAuditLogs.map((entry)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                        className: "rounded border border-slate-800 bg-slate-950/50 px-3 py-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] font-bold uppercase text-white",
                                        children: ACTION_LABELS[entry.action_type] ?? entry.action_type
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/AuditIntelligence.tsx",
                                        lineNumber: 84,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[9px] text-slate-400",
                                        children: entry.timestamp
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/AuditIntelligence.tsx",
                                        lineNumber: 85,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/AuditIntelligence.tsx",
                                lineNumber: 83,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-[10px] text-slate-300",
                                children: entry.description
                            }, void 0, false, {
                                fileName: "[project]/app/components/AuditIntelligence.tsx",
                                lineNumber: 87,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-[9px] uppercase tracking-wide text-slate-500",
                                children: [
                                    "user_id=",
                                    entry.user_id,
                                    " | ip_address=",
                                    entry.ip_address
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/AuditIntelligence.tsx",
                                lineNumber: 88,
                                columnNumber: 15
                            }, this)
                        ]
                    }, entry.id, true, {
                        fileName: "[project]/app/components/AuditIntelligence.tsx",
                        lineNumber: 82,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/components/AuditIntelligence.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/AuditIntelligence.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, this);
}
_s(AuditIntelligence, "zxbctG+S3l/DIXHWyeGWggPO9bg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLoggerStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuditLoggerStore"]
    ];
});
_c = AuditIntelligence;
var _c;
__turbopack_context__.k.register(_c, "AuditIntelligence");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/HealthScoreBadge.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HealthScoreBadge
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/scoring.ts [app-client] (ecmascript)");
;
;
function gradeColor(grade) {
    if (grade.startsWith("A")) return "text-emerald-500";
    if (grade.startsWith("B")) return "text-blue-400";
    if (grade === "C") return "text-amber-400";
    if (grade === "D") return "text-orange-400";
    return "text-red-500";
}
function HealthScoreBadge({ entityData, scoreClassName = "text-5xl", tooltipAlign = "center" }) {
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateEntityScore"])(entityData);
    const aiInsight = `Score: ${result.score}. Deductions: ${result.criticalAssets} Critical Assets, ${result.vulnerableAssets} Vulnerable Assets, ${result.activeThreats} Open Threat${result.activeThreats === 1 ? "" : "s"}. Bonus: ${result.policyAttestation}% Policy Compliance.`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "group relative inline-flex flex-col items-center",
        title: aiInsight,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: `${scoreClassName} font-bold ${gradeColor(result.grade)}`,
                children: result.grade
            }, void 0, false, {
                fileName: "[project]/app/components/HealthScoreBadge.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1 text-[10px] font-bold uppercase tracking-wide text-slate-300",
                children: [
                    result.score,
                    "/100 AI SCORE"
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/HealthScoreBadge.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `pointer-events-none absolute z-20 hidden w-72 rounded border border-slate-700 bg-slate-950/95 p-3 text-[10px] text-slate-200 shadow-lg group-hover:block ${tooltipAlign === "left" ? "left-0 top-full mt-2" : "left-1/2 top-full mt-2 -translate-x-1/2"}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-bold text-white",
                        children: [
                            "AI Insight (",
                            result.grade,
                            ")"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/HealthScoreBadge.tsx",
                        lineNumber: 35,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-1 text-slate-300",
                        children: "Base 100 − (Critical × 15) − (Vulnerable × 10) − (Active Threats × 20) + Policy Bonus"
                    }, void 0, false, {
                        fileName: "[project]/app/components/HealthScoreBadge.tsx",
                        lineNumber: 36,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        className: "mt-2 space-y-1 text-slate-300",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: [
                                    "Critical Assets: ",
                                    result.criticalAssets,
                                    " × -15"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/HealthScoreBadge.tsx",
                                lineNumber: 38,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: [
                                    "Vulnerable Assets: ",
                                    result.vulnerableAssets,
                                    " × -10"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/HealthScoreBadge.tsx",
                                lineNumber: 39,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: [
                                    "Open Threats: ",
                                    result.activeThreats,
                                    " × -20"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/HealthScoreBadge.tsx",
                                lineNumber: 40,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: [
                                    "Policy Attestation Bonus: ",
                                    result.policyAttestation,
                                    "% → +",
                                    result.bonusPoints
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/HealthScoreBadge.tsx",
                                lineNumber: 41,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/HealthScoreBadge.tsx",
                        lineNumber: 37,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 font-semibold text-white",
                        children: [
                            "Final Score: ",
                            result.score,
                            " (",
                            result.grade,
                            ")"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/HealthScoreBadge.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/HealthScoreBadge.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/HealthScoreBadge.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
_c = HealthScoreBadge;
var _c;
__turbopack_context__.k.register(_c, "HealthScoreBadge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/StrategicIntel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StrategicIntel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$target$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Target$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/target.js [app-client] (ecmascript) <export default as Target>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Brain$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/brain.js [app-client] (ecmascript) <export default as Brain>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Shield$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shield.js [app-client] (ecmascript) <export default as Shield>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pencil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pencil$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/pencil.js [app-client] (ecmascript) <export default as Pencil>");
;
;
const HEALTH_TEXT_STYLE = {
    HEALTHY: "text-emerald-400",
    DEGRADED: "text-amber-400",
    CRITICAL: "text-red-400"
};
const HEALTH_DOT_STYLE = {
    HEALTHY: "bg-emerald-500",
    DEGRADED: "bg-amber-400",
    CRITICAL: "bg-red-500"
};
function StrategicIntel({ agentHealth, phoneHomeAlert, coreintelLiveFeed }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-4 text-slate-200 bg-slate-950 p-4 h-full font-sans border-r border-slate-800",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between border-b border-slate-800 pb-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[11px] font-bold tracking-wider uppercase",
                                children: "STRATEGIC INTEL"
                            }, void 0, false, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 38,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pencil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pencil$3e$__["Pencil"], {
                                className: "w-3 h-3 text-slate-500"
                            }, void 0, false, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 39,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 37,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `text-[9px] font-bold ${HEALTH_TEXT_STYLE[agentHealth.agentManager]}`,
                                children: [
                                    "AGENT MANAGER: ",
                                    agentHealth.agentManager
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 42,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `w-1.5 h-1.5 rounded-full ${HEALTH_DOT_STYLE[agentHealth.agentManager]} animate-pulse`
                            }, void 0, false, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 45,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 41,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/StrategicIntel.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            phoneHomeAlert && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded border border-red-500/70 bg-red-500/15 px-3 py-2 text-[10px] font-bold uppercase tracking-wide text-red-300",
                children: [
                    phoneHomeAlert,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        href: "mailto:support@ironframe.local",
                        className: "ml-2 underline text-red-200",
                        children: "Contact Support"
                    }, void 0, false, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 52,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/StrategicIntel.tsx",
                lineNumber: 50,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] font-bold text-slate-400 uppercase",
                                children: "INDUSTRY PROFILE"
                            }, void 0, false, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 61,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[9px] text-blue-400 cursor-pointer hover:underline",
                                children: "Hide"
                            }, void 0, false, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 62,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 60,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-slate-900 border border-slate-800 p-2 rounded text-[11px] text-slate-300",
                        children: "Healthcare"
                    }, void 0, false, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "w-full bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-bold py-1.5 rounded transition-colors shadow-sm",
                        children: "Load Strategy"
                    }, void 0, false, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 67,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/StrategicIntel.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[10px] font-bold text-slate-400 uppercase",
                        children: "RISK EXPOSURE"
                    }, void 0, false, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-between text-[10px] font-bold uppercase",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-slate-400",
                                                children: "INDUSTRY AVERAGE"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                                lineNumber: 79,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-blue-400",
                                                children: "$8.5M"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                                lineNumber: 80,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/StrategicIntel.tsx",
                                        lineNumber: 78,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-1 bg-slate-800 rounded-full overflow-hidden",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-full bg-blue-500 w-[55%]"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/StrategicIntel.tsx",
                                            lineNumber: 83,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/StrategicIntel.tsx",
                                        lineNumber: 82,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 77,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-between text-[10px] font-bold uppercase",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-slate-400",
                                                children: "YOUR CURRENT RISK"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                                lineNumber: 89,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-yellow-500",
                                                children: "$10.9M"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                                lineNumber: 90,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/StrategicIntel.tsx",
                                        lineNumber: 88,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-1 bg-slate-800 rounded-full overflow-hidden",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-full bg-yellow-500 w-[70%]"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/StrategicIntel.tsx",
                                            lineNumber: 93,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/StrategicIntel.tsx",
                                        lineNumber: 92,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 87,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-between text-[10px] font-bold uppercase",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-slate-400",
                                                children: "POTENTIAL IMPACT"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                                lineNumber: 99,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-red-500",
                                                children: "$15.2M"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                                lineNumber: 100,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/StrategicIntel.tsx",
                                        lineNumber: 98,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-1 bg-slate-800 rounded-full overflow-hidden",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-full bg-red-500 w-[85%]"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/StrategicIntel.tsx",
                                            lineNumber: 103,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/StrategicIntel.tsx",
                                        lineNumber: 102,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 97,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/StrategicIntel.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[10px] font-bold text-slate-400 uppercase",
                        children: "TOP SECTOR THREATS (CLICK TO REGISTER)"
                    }, void 0, false, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 111,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-1.5",
                        children: [
                            "RANSOMWARE",
                            "DATA BREACH",
                            "PHISHING ATTACK"
                        ].map((threat, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center bg-slate-900/50 border border-slate-800 px-3 py-2 rounded cursor-pointer hover:bg-slate-800 transition-colors",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[10px] font-bold",
                                        children: threat
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/StrategicIntel.tsx",
                                        lineNumber: 115,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[10px] font-bold text-emerald-400",
                                        children: [
                                            "$",
                                            i === 0 ? "4.9M" : i === 1 ? "3.5M" : "2.1M"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/StrategicIntel.tsx",
                                        lineNumber: 116,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, threat, true, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 114,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 112,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/StrategicIntel.tsx",
                lineNumber: 110,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[10px] font-bold text-slate-400 uppercase",
                        children: "AI AGENTS"
                    }, void 0, false, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-3 gap-2",
                        children: [
                            {
                                name: "IRONSIGHT",
                                icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$target$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Target$3e$__["Target"],
                                color: "text-red-500",
                                health: agentHealth.ironsight
                            },
                            {
                                name: "COREINTEL",
                                icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$brain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Brain$3e$__["Brain"],
                                color: "text-pink-400",
                                health: agentHealth.coreintel
                            },
                            {
                                name: "AGENT MANAGER",
                                icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Shield$3e$__["Shield"],
                                color: "text-slate-300",
                                health: agentHealth.agentManager
                            }
                        ].map((agent)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col items-center gap-1.5 bg-slate-900/50 border border-slate-800 p-2 rounded",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(agent.icon, {
                                        className: `w-4 h-4 ${agent.color}`
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/StrategicIntel.tsx",
                                        lineNumber: 134,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[8px] font-bold text-slate-400",
                                        children: agent.name
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/StrategicIntel.tsx",
                                        lineNumber: 135,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `w-1 h-1 rounded-full ${HEALTH_DOT_STYLE[agent.health]}`
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                                lineNumber: 137,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `text-[7px] font-bold uppercase ${HEALTH_TEXT_STYLE[agent.health]}`,
                                                children: agent.health
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                                lineNumber: 138,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/StrategicIntel.tsx",
                                        lineNumber: 136,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, agent.name, true, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 133,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 127,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/StrategicIntel.tsx",
                lineNumber: 125,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[10px] font-bold text-slate-400 uppercase",
                        children: "COREINTEL // LIVE INTELLIGENCE STREAM"
                    }, void 0, false, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 146,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-h-24 overflow-y-auto rounded border border-slate-800 bg-black/50 p-2 font-mono text-[9px] text-cyan-200",
                        children: coreintelLiveFeed.map((line, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "whitespace-nowrap",
                                children: line
                            }, `${line}-${index}`, false, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 149,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 147,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/StrategicIntel.tsx",
                lineNumber: 145,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-auto pt-4 space-y-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-3 gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-center rounded border border-slate-800 bg-slate-900 px-2 py-1.5",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-1.5 w-1.5 rounded-full bg-slate-500"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/StrategicIntel.tsx",
                                    lineNumber: 160,
                                    columnNumber: 14
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 159,
                                columnNumber: 12
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "rounded bg-blue-600 px-2 py-1.5 text-[10px] font-bold uppercase text-white hover:bg-blue-500",
                                children: "SET"
                            }, void 0, false, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 162,
                                columnNumber: 12
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-center rounded border border-amber-500/40 bg-amber-500/10 px-2 py-1.5 text-[10px] font-bold text-amber-300",
                                children: "TTL: 00:00:00"
                            }, void 0, false, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 165,
                                columnNumber: 12
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 158,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "text-[10px] font-semibold text-slate-400",
                                children: "Enter Agent Instruction..."
                            }, void 0, false, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 171,
                                columnNumber: 12
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                className: "w-full rounded border border-slate-800 bg-slate-900 px-2 py-1.5 text-[10px] text-slate-200 outline-none placeholder:text-slate-500",
                                placeholder: "Enter Agent Instruction..."
                            }, void 0, false, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 172,
                                columnNumber: 12
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 170,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "w-full bg-amber-400 hover:bg-amber-300 text-slate-900 font-extrabold text-[11px] py-3 rounded flex items-center justify-center gap-2 transition-colors shadow-lg uppercase",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                className: "w-4 h-4"
                            }, void 0, false, {
                                fileName: "[project]/app/components/StrategicIntel.tsx",
                                lineNumber: 180,
                                columnNumber: 12
                            }, this),
                            "Run Sentinel Sweep"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/StrategicIntel.tsx",
                        lineNumber: 179,
                        columnNumber: 10
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/StrategicIntel.tsx",
                lineNumber: 157,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/StrategicIntel.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_c = StrategicIntel;
var _c;
__turbopack_context__.k.register(_c, "StrategicIntel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ThreatPipeline.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ThreatPipeline
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bot$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bot.js [app-client] (ecmascript) <export default as Bot>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ThreatPipeline({ supplyChainThreat, showSocStream, onRemediateSupplyChainThreat }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "border-b border-slate-800 bg-slate-900/50 px-4 py-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-3 flex items-center justify-between border-b border-slate-800 pb-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-[11px] font-bold tracking-wide text-white",
                    children: "MEDSHIELD THREAT PIPELINE"
                }, void 0, false, {
                    fileName: "[project]/app/components/ThreatPipeline.tsx",
                    lineNumber: 26,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/ThreatPipeline.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: [
                    showSocStream && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] font-bold uppercase tracking-wide text-slate-400",
                                        children: "SOC STREAM"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ThreatPipeline.tsx",
                                        lineNumber: 33,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: "rounded bg-emerald-500 px-3 py-1 text-[10px] font-bold text-white hover:bg-emerald-400",
                                                children: "Accept"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/ThreatPipeline.tsx",
                                                lineNumber: 35,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: "rounded border border-red-500 bg-slate-900 px-3 py-1 text-[10px] font-bold text-red-500 hover:bg-slate-800",
                                                children: "Reject"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/ThreatPipeline.tsx",
                                                lineNumber: 41,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/ThreatPipeline.tsx",
                                        lineNumber: 34,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/ThreatPipeline.tsx",
                                lineNumber: 32,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded border border-slate-800 bg-slate-950/40 p-2 text-[10px] text-slate-500",
                                children: "SOC stream empty."
                            }, void 0, false, {
                                fileName: "[project]/app/components/ThreatPipeline.tsx",
                                lineNumber: 49,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/ThreatPipeline.tsx",
                        lineNumber: 31,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] font-bold uppercase tracking-wide text-slate-400",
                                        children: "AGENT STREAM"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ThreatPipeline.tsx",
                                        lineNumber: 57,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: "rounded bg-emerald-500 px-3 py-1 text-[10px] font-bold text-white hover:bg-emerald-400",
                                                children: "Accept"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/ThreatPipeline.tsx",
                                                lineNumber: 59,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: "rounded border border-red-500 bg-slate-900 px-3 py-1 text-[10px] font-bold text-red-500 hover:bg-slate-800",
                                                children: "Reject"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/ThreatPipeline.tsx",
                                                lineNumber: 65,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/ThreatPipeline.tsx",
                                        lineNumber: 58,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/ThreatPipeline.tsx",
                                lineNumber: 56,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded border border-slate-800 bg-slate-950/40 p-2 text-[10px] text-slate-500",
                                children: "Agent stream empty."
                            }, void 0, false, {
                                fileName: "[project]/app/components/ThreatPipeline.tsx",
                                lineNumber: 73,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/ThreatPipeline.tsx",
                        lineNumber: 55,
                        columnNumber: 9
                    }, this),
                    supplyChainThreat && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] font-bold uppercase tracking-wide text-slate-400",
                                        children: "SUPPLY CHAIN ALERT"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ThreatPipeline.tsx",
                                        lineNumber: 81,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>{
                                            onRemediateSupplyChainThreat(supplyChainThreat.vendorName);
                                            router.push("/medshield/playbooks");
                                        },
                                        className: "rounded border border-blue-500/70 bg-blue-500/15 px-3 py-1 text-[10px] font-bold uppercase text-blue-200",
                                        children: "REMEDIATE"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ThreatPipeline.tsx",
                                        lineNumber: 82,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/ThreatPipeline.tsx",
                                lineNumber: 80,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded border border-slate-800 border-l-2 border-l-red-500 bg-slate-950/70 p-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-start gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bot$3e$__["Bot"], {
                                            className: "mt-0.5 h-4 w-4 text-slate-300"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/ThreatPipeline.tsx",
                                            lineNumber: 96,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "min-w-0",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-1 flex flex-wrap items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-[11px] font-bold text-white",
                                                            children: [
                                                                "Nth-Party Breach Detected: ",
                                                                supplyChainThreat.vendorName
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/components/ThreatPipeline.tsx",
                                                            lineNumber: 99,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "rounded bg-red-500/20 px-1.5 py-0.5 text-[10px] font-bold text-red-300",
                                                            children: "SUPPLY CHAIN"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/ThreatPipeline.tsx",
                                                            lineNumber: 100,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "rounded bg-red-500/20 px-1.5 py-0.5 text-[10px] font-bold text-red-300",
                                                            children: "CRITICAL ENTITY"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/ThreatPipeline.tsx",
                                                            lineNumber: 101,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/components/ThreatPipeline.tsx",
                                                    lineNumber: 98,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-[10px] text-slate-400",
                                                    children: supplyChainThreat.impact
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/ThreatPipeline.tsx",
                                                    lineNumber: 103,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "mt-1 text-[10px] text-slate-400",
                                                    children: [
                                                        "Source: ",
                                                        supplyChainThreat.source,
                                                        " | Liability: $",
                                                        supplyChainThreat.liabilityUsd.toLocaleString()
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/components/ThreatPipeline.tsx",
                                                    lineNumber: 104,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/components/ThreatPipeline.tsx",
                                            lineNumber: 97,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/ThreatPipeline.tsx",
                                    lineNumber: 95,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/ThreatPipeline.tsx",
                                lineNumber: 94,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/ThreatPipeline.tsx",
                        lineNumber: 79,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ThreatPipeline.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/ThreatPipeline.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
}
_s(ThreatPipeline, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = ThreatPipeline;
var _c;
__turbopack_context__.k.register(_c, "ThreatPipeline");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/store/vendorQuestionnaireStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addVendorAssessment",
    ()=>addVendorAssessment,
    "getEntityAssessmentSummary",
    ()=>getEntityAssessmentSummary,
    "getVendorAssessmentSnapshot",
    ()=>getVendorAssessmentSnapshot,
    "setVendorAssessmentSyncStatus",
    ()=>setVendorAssessmentSyncStatus,
    "subscribeVendorAssessments",
    ()=>subscribeVendorAssessments,
    "useVendorAssessmentStore",
    ()=>useVendorAssessmentStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/scoring.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const listeners = new Set();
let vendorAssessmentState = [];
function emitChange() {
    listeners.forEach((listener)=>listener());
}
function subscribeVendorAssessments(listener) {
    listeners.add(listener);
    return ()=>listeners.delete(listener);
}
function getVendorAssessmentSnapshot() {
    return vendorAssessmentState;
}
function addVendorAssessment(assessment) {
    const previousSubmission = vendorAssessmentState.find((record)=>record.entityKey === assessment.entityKey);
    const baselineScore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateEntityScore"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTITY_SCORING_DATA"][assessment.entityKey]).score;
    const previousScore = previousSubmission?.score ?? baselineScore;
    const record = {
        ...assessment,
        id: `vendor-assessment-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        createdAt: new Date().toISOString(),
        auditor: "AI AUDITOR",
        previousScore,
        scoreChange: assessment.score - previousScore
    };
    vendorAssessmentState = [
        record,
        ...vendorAssessmentState
    ];
    emitChange();
    return record;
}
function setVendorAssessmentSyncStatus(id, syncStatus) {
    let updated = null;
    vendorAssessmentState = vendorAssessmentState.map((record)=>{
        if (record.id !== id) {
            return record;
        }
        updated = {
            ...record,
            syncStatus
        };
        return updated;
    });
    if (updated) {
        emitChange();
    }
    return updated;
}
function getEntityAssessmentSummary(entity) {
    const entries = vendorAssessmentState.filter((record)=>record.entityKey === entity);
    const mfaFailures = entries.filter((record)=>!record.mfaEnabled).length;
    const additionalFinancialImpact = entries.reduce((sum, record)=>sum + record.potentialFinancialImpact, 0);
    return {
        entries,
        mfaFailures,
        additionalFinancialImpact,
        latest: entries[0] ?? null
    };
}
function useVendorAssessmentStore() {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribeVendorAssessments, getVendorAssessmentSnapshot, getVendorAssessmentSnapshot);
}
_s(useVendorAssessmentStore, "FpwL93IKMLJZuQQXefVtWynbBPQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/store/remediationStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applyRemediationSuccess",
    ()=>applyRemediationSuccess,
    "getRemediationSnapshot",
    ()=>getRemediationSnapshot,
    "setRemediationPending",
    ()=>setRemediationPending,
    "subscribeRemediation",
    ()=>subscribeRemediation,
    "useRemediationStore",
    ()=>useRemediationStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
const listeners = new Set();
let remediationState = {
    remediatedAssetIds: [],
    executionStatus: {},
    riskReductionByEntity: {
        medshield: 0,
        vaultbank: 0,
        gridcore: 0
    },
    auditTrail: []
};
function emitChange() {
    listeners.forEach((listener)=>listener());
}
function subscribeRemediation(listener) {
    listeners.add(listener);
    return ()=>listeners.delete(listener);
}
function getRemediationSnapshot() {
    return remediationState;
}
function setRemediationPending(taskId) {
    remediationState = {
        ...remediationState,
        executionStatus: {
            ...remediationState.executionStatus,
            [taskId]: "pending"
        }
    };
    emitChange();
}
function applyRemediationSuccess(input) {
    remediationState = {
        ...remediationState,
        remediatedAssetIds: remediationState.remediatedAssetIds.includes(input.assetId) ? remediationState.remediatedAssetIds : [
            input.assetId,
            ...remediationState.remediatedAssetIds
        ],
        executionStatus: {
            ...remediationState.executionStatus,
            [input.taskId]: "applied"
        },
        riskReductionByEntity: {
            ...remediationState.riskReductionByEntity,
            [input.entityKey]: remediationState.riskReductionByEntity[input.entityKey] + input.riskReduction
        },
        auditTrail: [
            input.auditRecord,
            ...remediationState.auditTrail
        ]
    };
    emitChange();
}
function useRemediationStore() {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribeRemediation, getRemediationSnapshot, getRemediationSnapshot);
}
_s(useRemediationStore, "FpwL93IKMLJZuQQXefVtWynbBPQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/store/regulatoryStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getRegulatorySnapshot",
    ()=>getRegulatorySnapshot,
    "subscribeRegulatory",
    ()=>subscribeRegulatory,
    "syncRegulatoryFeed",
    ()=>syncRegulatoryFeed,
    "useRegulatoryStore",
    ()=>useRegulatoryStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
const listeners = new Set();
let regulatoryState = {
    feed: [],
    autoTasks: [],
    vendorRegulatoryFeed: [],
    ticker: [],
    syncedAt: null,
    isSyncing: false,
    error: null
};
function emitChange() {
    listeners.forEach((listener)=>listener());
}
function subscribeRegulatory(listener) {
    listeners.add(listener);
    return ()=>listeners.delete(listener);
}
function getRegulatorySnapshot() {
    return regulatoryState;
}
function mergeById(current, incoming) {
    const map = new Map();
    for (const item of current){
        map.set(item.id, item);
    }
    for (const item of incoming){
        map.set(item.id, item);
    }
    return Array.from(map.values());
}
function mergeVendorFeed(current, incoming) {
    const map = new Map();
    for (const item of current){
        map.set(item.vendorName, item);
    }
    for (const item of incoming){
        map.set(item.vendorName, item);
    }
    return Array.from(map.values());
}
async function syncRegulatoryFeed() {
    regulatoryState = {
        ...regulatoryState,
        isSyncing: true,
        error: null
    };
    emitChange();
    try {
        const response = await fetch("/api/regulations/sync", {
            method: "POST",
            headers: {
                "content-type": "application/json"
            }
        });
        if (!response.ok) {
            throw new Error(`Regulation sync failed (${response.status})`);
        }
        const payload = await response.json();
        regulatoryState = {
            ...regulatoryState,
            feed: mergeById(regulatoryState.feed, payload.detectedRegulations),
            autoTasks: mergeById(regulatoryState.autoTasks, payload.autoTasks),
            vendorRegulatoryFeed: mergeVendorFeed(regulatoryState.vendorRegulatoryFeed, payload.vendorRegulatoryFeed),
            ticker: payload.ticker,
            syncedAt: payload.syncedAt,
            isSyncing: false,
            error: null
        };
    } catch (error) {
        regulatoryState = {
            ...regulatoryState,
            isSyncing: false,
            error: error.message
        };
    }
    emitChange();
}
function useRegulatoryStore() {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribeRegulatory, getRegulatorySnapshot, getRegulatorySnapshot);
}
_s(useRegulatoryStore, "FpwL93IKMLJZuQQXefVtWynbBPQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/store/systemConfigStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_VENDOR_EVIDENCE_REQUEST_TEMPLATE",
    ()=>DEFAULT_VENDOR_EVIDENCE_REQUEST_TEMPLATE,
    "getSystemConfigSnapshot",
    ()=>getSystemConfigSnapshot,
    "hydrateSystemConfig",
    ()=>hydrateSystemConfig,
    "setAdhocNotificationGroups",
    ()=>setAdhocNotificationGroups,
    "setAuthorizedSocDomains",
    ()=>setAuthorizedSocDomains,
    "setCadenceAlerts",
    ()=>setCadenceAlerts,
    "setCompanyStakeholders",
    ()=>setCompanyStakeholders,
    "setGeneralRfiChecklist",
    ()=>setGeneralRfiChecklist,
    "setSocAutoReceiptEnabled",
    ()=>setSocAutoReceiptEnabled,
    "setSocDepartmentEmail",
    ()=>setSocDepartmentEmail,
    "setSocEmailIntakeEnabled",
    ()=>setSocEmailIntakeEnabled,
    "setVendorDocumentUpdateTemplate",
    ()=>setVendorDocumentUpdateTemplate,
    "setVendorTypeRequirements",
    ()=>setVendorTypeRequirements,
    "subscribeSystemConfig",
    ()=>subscribeSystemConfig,
    "useSystemConfigStore",
    ()=>useSystemConfigStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/auditLogger.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const DEFAULT_VENDOR_EVIDENCE_REQUEST_TEMPLATE = "NIST 800-53 Evidence Request: Please provide updated control evidence, attestation artifacts, and remediation status for your assigned controls within 48 hours.";
const STORAGE_KEY = "ironframe-system-config-v1";
const listeners = new Set();
const DEFAULT_STAKEHOLDERS = [
    {
        id: "stakeholder-1",
        name: "",
        title: "CISO",
        email: "",
        department: "Security",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-2",
        name: "",
        title: "CRO",
        email: "",
        department: "Risk",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-3",
        name: "",
        title: "DPO",
        email: "",
        department: "Privacy",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-4",
        name: "",
        title: "CFO",
        email: "",
        department: "Finance",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-5",
        name: "",
        title: "General Counsel",
        email: "",
        department: "Legal",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-6",
        name: "",
        title: "Head of ITSM",
        email: "",
        department: "IT Operations",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-7",
        name: "",
        title: "Head of Product Security",
        email: "",
        department: "Product Security",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-8",
        name: "",
        title: "Audit Director",
        email: "",
        department: "Internal Audit",
        includeReadReceipt: false,
        readReceiptLog: []
    }
];
const DEFAULT_ADHOC_GROUPS = [
    {
        id: "group-1",
        name: "",
        emails: "",
        includeReadReceipt: false
    },
    {
        id: "group-2",
        name: "",
        emails: "",
        includeReadReceipt: false
    },
    {
        id: "group-3",
        name: "",
        emails: "",
        includeReadReceipt: false
    }
];
const DEFAULT_GENERAL_RFI_CHECKLIST = [
    "Privacy Policy",
    "Insurance",
    "Pen Test",
    "Disaster Recovery"
];
const DEFAULT_VENDOR_TYPE_REQUIREMENTS = {
    SaaS: [
        "SOC2",
        "Privacy Policy"
    ],
    "On-Prem Software": [
        "ISO 27001",
        "Vulnerability Scan Report"
    ],
    "Managed Services": [
        "SOC2",
        "Business Continuity Plan",
        "Incident Response Plan"
    ],
    Hardware: [
        "NIST 800-161",
        "ISO 9001"
    ]
};
let systemConfigState = {
    socEmailIntakeEnabled: false,
    socDepartmentEmail: "",
    socAutoReceiptEnabled: false,
    authorizedSocDomains: [
        "medshield.com"
    ],
    companyStakeholders: DEFAULT_STAKEHOLDERS,
    vendorDocumentUpdateTemplate: DEFAULT_VENDOR_EVIDENCE_REQUEST_TEMPLATE,
    adhocNotificationGroups: DEFAULT_ADHOC_GROUPS,
    cadenceAlerts: {
        day90: true,
        day60: true,
        day30: true
    },
    generalRfiChecklist: DEFAULT_GENERAL_RFI_CHECKLIST,
    vendorTypeRequirements: DEFAULT_VENDOR_TYPE_REQUIREMENTS
};
function emitChange() {
    listeners.forEach((listener)=>listener());
}
function sanitizeDomains(input) {
    return Array.from(new Set(input.map((entry)=>entry.trim().toLowerCase()).filter((entry)=>entry.length > 0).map((entry)=>entry.replace(/^@/, ""))));
}
function sanitizeStakeholders(input) {
    if (!input || input.length === 0) {
        return DEFAULT_STAKEHOLDERS;
    }
    const parsed = input.slice(0, 20).map((stakeholder, index)=>({
            id: stakeholder.id || `stakeholder-${index + 1}`,
            name: stakeholder.name?.trim() ?? "",
            title: stakeholder.title?.trim() ?? "",
            email: stakeholder.email?.trim() ?? "",
            department: stakeholder.department?.trim() ?? "",
            includeReadReceipt: Boolean(stakeholder.includeReadReceipt),
            readReceiptLog: Array.isArray(stakeholder.readReceiptLog) ? stakeholder.readReceiptLog.map((entry)=>String(entry).trim()).filter((entry)=>entry.length > 0) : []
        }));
    return parsed.length >= 8 ? parsed : [
        ...parsed,
        ...DEFAULT_STAKEHOLDERS.slice(parsed.length, 8)
    ];
}
function sanitizeAdhocGroups(input) {
    const fallback = DEFAULT_ADHOC_GROUPS;
    if (!input || input.length === 0) {
        return fallback;
    }
    const parsed = input.slice(0, 3).map((group, index)=>({
            id: group.id || `group-${index + 1}`,
            name: group.name?.trim() ?? "",
            emails: group.emails?.trim() ?? "",
            includeReadReceipt: Boolean(group.includeReadReceipt)
        }));
    while(parsed.length < 3){
        parsed.push(fallback[parsed.length]);
    }
    return parsed;
}
function sanitizeCadenceAlerts(input) {
    return {
        day90: input?.day90 ?? true,
        day60: input?.day60 ?? true,
        day30: input?.day30 ?? true
    };
}
function sanitizeChecklist(input) {
    const parsed = (input ?? []).map((entry)=>entry.trim()).filter((entry)=>entry.length > 0);
    if (parsed.length === 0) {
        return DEFAULT_GENERAL_RFI_CHECKLIST;
    }
    return Array.from(new Set(parsed));
}
function sanitizeVendorTypeRequirements(input) {
    const source = input ?? {};
    return {
        SaaS: sanitizeChecklist(source.SaaS),
        "On-Prem Software": sanitizeChecklist(source["On-Prem Software"]),
        "Managed Services": sanitizeChecklist(source["Managed Services"]),
        Hardware: sanitizeChecklist(source.Hardware)
    };
}
function hydrateSystemConfig() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const raw = window.localStorage.getItem(STORAGE_KEY);
        if (!raw) {
            return;
        }
        const parsed = JSON.parse(raw);
        systemConfigState = {
            socEmailIntakeEnabled: parsed.socEmailIntakeEnabled ?? false,
            socDepartmentEmail: parsed.socDepartmentEmail?.trim() ?? "",
            socAutoReceiptEnabled: parsed.socAutoReceiptEnabled ?? false,
            authorizedSocDomains: sanitizeDomains(parsed.authorizedSocDomains ?? []),
            companyStakeholders: sanitizeStakeholders(parsed.companyStakeholders),
            vendorDocumentUpdateTemplate: parsed.vendorDocumentUpdateTemplate?.trim() || DEFAULT_VENDOR_EVIDENCE_REQUEST_TEMPLATE,
            adhocNotificationGroups: sanitizeAdhocGroups(parsed.adhocNotificationGroups),
            cadenceAlerts: sanitizeCadenceAlerts(parsed.cadenceAlerts),
            generalRfiChecklist: sanitizeChecklist(parsed.generalRfiChecklist),
            vendorTypeRequirements: sanitizeVendorTypeRequirements(parsed.vendorTypeRequirements)
        };
        emitChange();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureLoginAuditEvent"])();
    } catch  {
    // no-op
    }
}
function persistSystemConfig() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(systemConfigState));
}
function subscribeSystemConfig(listener) {
    listeners.add(listener);
    return ()=>listeners.delete(listener);
}
function getSystemConfigSnapshot() {
    return systemConfigState;
}
function setSocEmailIntakeEnabled(enabled) {
    systemConfigState = {
        ...systemConfigState,
        socEmailIntakeEnabled: enabled
    };
    persistSystemConfig();
    emitChange();
}
function setSocDepartmentEmail(email) {
    const value = email.trim();
    systemConfigState = {
        ...systemConfigState,
        socDepartmentEmail: value
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendAuditLog"])({
        action_type: "CONFIG_CHANGE",
        log_type: "GRC",
        metadata_tag: "GRC_GOVERNANCE",
        description: `SOC department email updated to ${value || "(empty)"}.`
    });
    persistSystemConfig();
    emitChange();
}
function setSocAutoReceiptEnabled(enabled) {
    systemConfigState = {
        ...systemConfigState,
        socAutoReceiptEnabled: enabled
    };
    persistSystemConfig();
    emitChange();
}
function setAuthorizedSocDomains(domains) {
    systemConfigState = {
        ...systemConfigState,
        authorizedSocDomains: sanitizeDomains(domains)
    };
    persistSystemConfig();
    emitChange();
}
function setCompanyStakeholders(stakeholders) {
    const sanitized = sanitizeStakeholders(stakeholders);
    systemConfigState = {
        ...systemConfigState,
        companyStakeholders: sanitized
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendAuditLog"])({
        action_type: "CONFIG_CHANGE",
        log_type: "GRC",
        metadata_tag: "GRC_GOVERNANCE",
        description: `Stakeholder table saved (${sanitized.filter((entry)=>entry.email.length > 0).length} email targets configured).`
    });
    persistSystemConfig();
    emitChange();
}
function setVendorDocumentUpdateTemplate(template) {
    const value = template.trim();
    systemConfigState = {
        ...systemConfigState,
        vendorDocumentUpdateTemplate: value
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendAuditLog"])({
        action_type: "CONFIG_CHANGE",
        log_type: "GRC",
        metadata_tag: "GRC_GOVERNANCE",
        description: `Vendor evidence template updated (${value.length} chars).`
    });
    persistSystemConfig();
    emitChange();
}
function setAdhocNotificationGroups(groups) {
    systemConfigState = {
        ...systemConfigState,
        adhocNotificationGroups: sanitizeAdhocGroups(groups)
    };
    persistSystemConfig();
    emitChange();
}
function setCadenceAlerts(cadenceAlerts) {
    systemConfigState = {
        ...systemConfigState,
        cadenceAlerts: sanitizeCadenceAlerts(cadenceAlerts)
    };
    persistSystemConfig();
    emitChange();
}
function setGeneralRfiChecklist(checklist) {
    const sanitized = sanitizeChecklist(checklist);
    systemConfigState = {
        ...systemConfigState,
        generalRfiChecklist: sanitized
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendAuditLog"])({
        action_type: "CONFIG_CHANGE",
        log_type: "GRC",
        metadata_tag: "GRC_GOVERNANCE",
        description: `General RFI checklist updated (${sanitized.length} items).`
    });
    persistSystemConfig();
    emitChange();
}
function setVendorTypeRequirements(requirements) {
    const sanitized = sanitizeVendorTypeRequirements(requirements);
    systemConfigState = {
        ...systemConfigState,
        vendorTypeRequirements: sanitized
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendAuditLog"])({
        action_type: "CONFIG_CHANGE",
        log_type: "GRC",
        metadata_tag: "GRC_GOVERNANCE",
        description: "Vendor type evidence requirements updated."
    });
    persistSystemConfig();
    emitChange();
}
function useSystemConfigStore() {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribeSystemConfig, getSystemConfigSnapshot, getSystemConfigSnapshot);
}
_s(useSystemConfigStore, "FpwL93IKMLJZuQQXefVtWynbBPQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/coreintel.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchIndustryIntelligence",
    ()=>fetchIndustryIntelligence
]);
async function fetchIndustryIntelligence() {
    return Promise.resolve([
        {
            id: "trend-healthcare-ransomware-variant",
            summary: "New Ransomware Variant detected in Healthcare",
            sector: "Healthcare",
            severity: "HIGH"
        },
        {
            id: "trend-finance-third-party-api-abuse",
            summary: "Third-party API abuse attempts rising in Finance",
            sector: "Finance",
            severity: "MEDIUM"
        }
    ]);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/socIntake.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parseSocEmailToAlert",
    ()=>parseSocEmailToAlert,
    "simulateSocEmail",
    ()=>simulateSocEmail
]);
function deriveSeverity(subject, liabilityUsd) {
    const normalized = subject.toUpperCase();
    if (normalized.includes("CRITICAL")) {
        return Math.min(100, Math.round(liabilityUsd / 12_000_000 * 100));
    }
    if (normalized.includes("HIGH")) {
        return 74;
    }
    return 52;
}
function parseSocEmailToAlert(email, context) {
    if (!context.enabled) {
        return {
            alert: null,
            rejectionReason: "ENGINE_DISABLED",
            senderDomain: "",
            isVerifiedSender: false
        };
    }
    const senderDomain = email.sender.split("@").at(1)?.trim().toLowerCase().replace(/^@/, "") ?? "";
    const domain = senderDomain;
    const domainIsAuthorized = context.authorizedDomains.includes(domain);
    if (!domainIsAuthorized) {
        return {
            alert: null,
            rejectionReason: "UNAUTHORIZED_SENDER",
            senderDomain,
            isVerifiedSender: false
        };
    }
    const liabilityUsd = 11_100_000;
    const severityScore = deriveSeverity(email.subject, liabilityUsd);
    return {
        alert: {
            id: `soc-${email.id}`,
            title: email.subject.startsWith("CRITICAL:") ? email.subject.replace("CRITICAL:", "").trim() : email.subject,
            impact: "External SOC escalation mapped to Tier 1 exposure with upstream vendor dependency risk.",
            severityScore,
            liabilityUsd,
            createdAt: email.receivedAt
        },
        rejectionReason: null,
        senderDomain,
        isVerifiedSender: true
    };
}
function simulateSocEmail() {
    return {
        id: "critical-firewall-breach-medshield",
        sender: "alerts@medshield.com",
        subject: "CRITICAL: Firewall Breach",
        body: "Potential perimeter bypass observed on SOC telemetry.",
        receivedAt: new Date().toISOString()
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/retentionPolicy.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RETENTION_PERIOD_DAYS",
    ()=>RETENTION_PERIOD_DAYS,
    "getRetentionStatusLabel",
    ()=>getRetentionStatusLabel,
    "maskSensitiveData",
    ()=>maskSensitiveData
]);
const RETENTION_PERIOD_DAYS = 2555;
const EMAIL_REGEX = /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi;
const SSN_REGEX = /\b\d{3}-\d{2}-\d{4}\b/g;
function maskSensitiveData(input) {
    return input.replace(EMAIL_REGEX, "[MASKED_EMAIL]").replace(SSN_REGEX, "[MASKED_SSN]");
}
function getRetentionStatusLabel() {
    return `Retention Status: ACTIVE (${RETENTION_PERIOD_DAYS} days)`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/mailHub.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getMailHubSnapshot",
    ()=>getMailHubSnapshot,
    "getOutboundMailLog",
    ()=>getOutboundMailLog,
    "getUnresponsiveVendorRequests",
    ()=>getUnresponsiveVendorRequests,
    "logReadReceipt",
    ()=>logReadReceipt,
    "receiveSocDepartmentEmail",
    ()=>receiveSocDepartmentEmail,
    "sendAdhocGroupNotification",
    ()=>sendAdhocGroupNotification,
    "sendSocDepartmentEmail",
    ()=>sendSocDepartmentEmail,
    "sendStakeholderBlast",
    ()=>sendStakeholderBlast,
    "sendStakeholderCadenceEscalation",
    ()=>sendStakeholderCadenceEscalation,
    "sendVendorDocumentUpdateRequest",
    ()=>sendVendorDocumentUpdateRequest,
    "sendVendorUpcomingExpirationReminder",
    ()=>sendVendorUpcomingExpirationReminder,
    "subscribeMailHub",
    ()=>subscribeMailHub
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/auditLogger.ts [app-client] (ecmascript)");
;
const APPROVED_SENDER = {
    name: "Dereck",
    email: "dereck@ironframe.local"
};
const listeners = new Set();
let mailHubState = {
    outbound: [],
    inboundSoc: []
};
function emitChange() {
    listeners.forEach((listener)=>listener());
}
function nextMailId() {
    return `mail-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
}
function createTrackingPixelUrl(id) {
    return `/api/mail/receipt/${id}.png`;
}
function sendTrackedMail(input) {
    const id = nextMailId();
    const sentAt = new Date().toISOString();
    const requireReadReceipt = input.requireReadReceipt ?? true;
    const record = {
        id,
        sentAt,
        recipientEmail: input.recipientEmail,
        recipientTitle: input.recipientTitle,
        subject: input.subject,
        body: input.body,
        channel: input.channel,
        approvedSenderName: APPROVED_SENDER.name,
        approvedSenderEmail: APPROVED_SENDER.email,
        requireReadReceipt,
        trackingPixelUrl: createTrackingPixelUrl(id),
        priority: input.priority ?? "NORMAL",
        cadenceMilestone: input.cadenceMilestone ?? null,
        readStatus: "PENDING",
        readAt: null,
        vendorName: input.vendorName
    };
    mailHubState = {
        ...mailHubState,
        outbound: [
            record,
            ...mailHubState.outbound
        ].slice(0, 500)
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendAuditLog"])({
        action_type: "EMAIL_SENT",
        description: `${record.subject} -> ${record.recipientTitle} (${record.recipientEmail}) [${record.channel}]`
    });
    emitChange();
    return record;
}
function sendSocDepartmentEmail(input) {
    return sendTrackedMail({
        ...input,
        channel: "SOC",
        requireReadReceipt: true
    });
}
function receiveSocDepartmentEmail(message) {
    mailHubState = {
        ...mailHubState,
        inboundSoc: [
            {
                id: nextMailId(),
                receivedAt: new Date().toISOString(),
                from: message.from,
                subject: message.subject,
                body: message.body
            },
            ...mailHubState.inboundSoc
        ].slice(0, 200)
    };
    const autoReceipt = sendTrackedMail({
        recipientEmail: message.from,
        recipientTitle: "SOC Sender",
        subject: `Auto-Receipt: ${message.subject}`,
        body: "SOC department received your message.",
        channel: "SOC",
        requireReadReceipt: false
    });
    emitChange();
    return autoReceipt;
}
function sendAdhocGroupNotification(slot, group, message) {
    return sendTrackedMail({
        recipientEmail: group.emails,
        recipientTitle: `Ad-hoc Group Slot ${slot}`,
        subject: group.name ? `GRC Group Notification: ${group.name}` : `GRC Group Notification Slot ${slot}`,
        body: message,
        channel: "ADHOC_GROUP",
        requireReadReceipt: group.includeReadReceipt
    });
}
function sendStakeholderBlast(input) {
    return sendTrackedMail({
        recipientEmail: input.recipientEmail,
        recipientTitle: input.recipientTitle,
        subject: input.subject,
        body: input.body,
        channel: "STAKEHOLDER_BLAST",
        requireReadReceipt: input.requireReadReceipt
    });
}
function sendVendorDocumentUpdateRequest(vendorName, vendorEmail, template, options) {
    return sendTrackedMail({
        recipientEmail: vendorEmail,
        recipientTitle: "Vendor Compliance Contact",
        subject: `Document Update Request // ${vendorName}`,
        body: `${template}\n\nTracking Pixel: mandatory read receipt enabled.`,
        channel: "VENDOR_DOC_REQUEST",
        requireReadReceipt: true,
        cadenceMilestone: options?.cadenceMilestone,
        priority: options?.priority ?? "NORMAL",
        vendorName
    });
}
function sendVendorUpcomingExpirationReminder(vendorName, vendorEmail, daysUntilExpiration) {
    return sendTrackedMail({
        recipientEmail: vendorEmail,
        recipientTitle: "Vendor Compliance Contact",
        subject: `Upcoming Expiration (Low Priority) // ${vendorName}`,
        body: `Courtesy Reminder: your compliance evidence package expires in ${Math.max(daysUntilExpiration, 0)} days. Please prepare updated artifacts.`,
        channel: "CADENCE_90_VENDOR",
        requireReadReceipt: true,
        priority: "LOW",
        cadenceMilestone: "90",
        vendorName
    });
}
function sendStakeholderCadenceEscalation(input) {
    return sendTrackedMail({
        recipientEmail: input.recipientEmail,
        recipientTitle: input.recipientTitle,
        subject: `High Priority // 30-Day Vendor Lapse Alert // ${input.vendorName}`,
        body: `Vendor ${input.vendorName} evidence expires in ${Math.max(input.daysUntilExpiration, 0)} days. This 30-day escalation is auto-routed to CISO and Legal Counsel.`,
        channel: "CADENCE_30_STAKEHOLDER",
        requireReadReceipt: input.requireReadReceipt,
        priority: input.priority,
        cadenceMilestone: "30",
        vendorName: input.vendorName
    });
}
function logReadReceipt(mailId) {
    let updated = false;
    mailHubState = {
        ...mailHubState,
        outbound: mailHubState.outbound.map((mail)=>{
            if (mail.id !== mailId || mail.readStatus === "ACKNOWLEDGED") {
                return mail;
            }
            updated = true;
            return {
                ...mail,
                readStatus: "ACKNOWLEDGED",
                readAt: new Date().toISOString()
            };
        })
    };
    if (updated) {
        emitChange();
    }
}
function getUnresponsiveVendorRequests(now = Date.now()) {
    const timeoutMs = 48 * 60 * 60 * 1000;
    return mailHubState.outbound.filter((mail)=>{
        if (mail.channel !== "VENDOR_DOC_REQUEST" || !mail.vendorName) {
            return false;
        }
        if (mail.readStatus === "ACKNOWLEDGED") {
            return false;
        }
        const ageMs = now - new Date(mail.sentAt).getTime();
        return ageMs >= timeoutMs;
    });
}
function subscribeMailHub(listener) {
    listeners.add(listener);
    return ()=>listeners.delete(listener);
}
function getMailHubSnapshot() {
    return mailHubState;
}
function getOutboundMailLog() {
    return mailHubState.outbound.slice(0, 500);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/mailHubStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMailHubStore",
    ()=>useMailHubStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$mailHub$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/mailHub.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function useMailHubStore() {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$mailHub$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["subscribeMailHub"], __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$mailHub$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMailHubSnapshot"], __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$mailHub$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMailHubSnapshot"]);
}
_s(useMailHubStore, "FpwL93IKMLJZuQQXefVtWynbBPQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Page
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ActiveRisks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ActiveRisks.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$AgentStream$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/AgentStream.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$AuditIntelligence$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/AuditIntelligence.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$HealthScoreBadge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/HealthScoreBadge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$StrategicIntel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/StrategicIntel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ThreatPipeline$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ThreatPipeline.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$vendorQuestionnaireStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/vendorQuestionnaireStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$remediationStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/remediationStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$regulatoryStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/regulatoryStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$systemConfigStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/systemConfigStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$coreintel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/coreintel.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$socIntake$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/socIntake.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$retentionPolicy$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/retentionPolicy.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$mailHub$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/mailHub.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$mailHubStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/mailHubStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/scoring.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const BASELINE_VENDOR_REGULATORY_STATUS = new Map([
    [
        "Azure Health",
        "COMPLIANT"
    ],
    [
        "KubeOps EU-West",
        "UNDER REVIEW"
    ],
    [
        "SWIFT",
        "COMPLIANT"
    ]
]);
function Page() {
    _s();
    const vendorAssessments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$vendorQuestionnaireStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVendorAssessmentStore"])();
    const remediationState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$remediationStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRemediationStore"])();
    const regulatoryState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$regulatoryStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRegulatoryStore"])();
    const systemConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$systemConfigStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSystemConfigStore"])();
    const mailHubState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$mailHubStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMailHubStore"])();
    const recentSubmissions = vendorAssessments.slice(0, 6);
    const [supplyChainViolation, setSupplyChainViolation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [phoneHomeAlert, setPhoneHomeAlert] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [medshieldTrendMultiplier, setMedshieldTrendMultiplier] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [coreintelTrendActive, setCoreintelTrendActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [coreintelLiveFeed, setCoreintelLiveFeed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        "Analyzing NIST 800-53 Rev 5 updates...",
        "Ingesting CISA Zero-Day feed...",
        "Cross-mapping vendor controls against HIPAA safeguards..."
    ]);
    const [heartbeatFailure, setHeartbeatFailure] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [agentStreamAlerts, setAgentStreamAlerts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [pipelineSupplyChainThreat, setPipelineSupplyChainThreat] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [heuristicAnomalyDetectionEnabled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const previousVendorStatusRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map(BASELINE_VENDOR_REGULATORY_STATUS));
    const simulatedSocEmailProcessedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const anomalyCooldownRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    const processedCadenceDispatchIdsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Set());
    const calculateCoreintelSeverity = (liabilityUsd)=>{
        return Math.min(100, Math.round(liabilityUsd / 12_000_000 * 100));
    };
    const appendOrchestrationLog = (message)=>{
        void message;
    };
    const appendCoreintelFeed = (message)=>{
        setCoreintelLiveFeed((current)=>[
                message,
                ...current
            ].slice(0, 20));
    };
    const setSupplyChainThreat = (vendorName, liabilityUsd)=>{
        setPipelineSupplyChainThreat({
            vendorName,
            impact: "Azure Health (Tier 1 Vendor) is now COMPROMISED.",
            severity: "CRITICAL",
            source: "Nth-Party Map",
            liabilityUsd
        });
    };
    const upsertAgentAlert = (nextAlert)=>{
        setAgentStreamAlerts((current)=>{
            if (current.some((entry)=>entry.id === nextAlert.id)) {
                return current;
            }
            return [
                nextAlert,
                ...current
            ].slice(0, 20);
        });
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$systemConfigStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hydrateSystemConfig"])();
        }
    }["Page.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            if (regulatoryState.feed.length === 0 && !regulatoryState.isSyncing) {
                void (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$regulatoryStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["syncRegulatoryFeed"])();
            }
        }
    }["Page.useEffect"], [
        regulatoryState.feed.length,
        regulatoryState.isSyncing
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            if (!systemConfig.socDepartmentEmail.trim()) {
                simulatedSocEmailProcessedRef.current = false;
                return;
            }
            if (!systemConfig.socEmailIntakeEnabled) {
                simulatedSocEmailProcessedRef.current = false;
                return;
            }
            if (simulatedSocEmailProcessedRef.current) {
                return;
            }
            const email = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$socIntake$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["simulateSocEmail"])();
            const parsedResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$socIntake$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseSocEmailToAlert"])(email, {
                enabled: systemConfig.socEmailIntakeEnabled,
                authorizedDomains: systemConfig.authorizedSocDomains
            });
            if (!parsedResult.alert) {
                if (parsedResult.rejectionReason === "UNAUTHORIZED_SENDER") {
                    const blockedLog = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$retentionPolicy$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maskSensitiveData"])(`${new Date().toISOString()} Unauthorized Sender // sender_domain=${parsedResult.senderDomain} sender_email=${email.sender}`);
                    queueMicrotask({
                        "Page.useEffect": ()=>{
                            appendOrchestrationLog(blockedLog);
                            appendCoreintelFeed(`[EXTERNAL SOC] Unauthorized sender blocked: ${parsedResult.senderDomain}.`);
                        }
                    }["Page.useEffect"]);
                }
                simulatedSocEmailProcessedRef.current = true;
                return;
            }
            const socAlert = parsedResult.alert;
            queueMicrotask({
                "Page.useEffect": ()=>{
                    upsertAgentAlert({
                        ...socAlert,
                        type: "SOC_EMAIL",
                        origin: "SOC_INTAKE",
                        isExternalSOC: parsedResult.isVerifiedSender,
                        sourceAgent: "EXTERNAL SOC",
                        title: socAlert.title === "Firewall Breach" ? "CRITICAL: Firewall Breach" : socAlert.title,
                        status: "OPEN"
                    });
                }
            }["Page.useEffect"]);
            queueMicrotask({
                "Page.useEffect": ()=>{
                    appendCoreintelFeed(`[EXTERNAL SOC] Authorized alert ingested from ${email.sender}.`);
                }
            }["Page.useEffect"]);
            simulatedSocEmailProcessedRef.current = true;
        }
    }["Page.useEffect"], [
        systemConfig.authorizedSocDomains,
        systemConfig.socDepartmentEmail,
        systemConfig.socEmailIntakeEnabled
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            let active = true;
            void (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$coreintel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchIndustryIntelligence"])().then({
                "Page.useEffect": (trends)=>{
                    if (!active) {
                        return;
                    }
                    const hasHealthcareRansomwareTrend = trends.some({
                        "Page.useEffect.hasHealthcareRansomwareTrend": (trend)=>trend.summary === "New Ransomware Variant detected in Healthcare"
                    }["Page.useEffect.hasHealthcareRansomwareTrend"]);
                    setCoreintelLiveFeed({
                        "Page.useEffect": (current)=>{
                            const trendLines = trends.map({
                                "Page.useEffect.trendLines": (trend)=>`Knowledge Ingestion // ${trend.summary}`
                            }["Page.useEffect.trendLines"]);
                            return [
                                ...trendLines,
                                ...current
                            ].slice(0, 12);
                        }
                    }["Page.useEffect"]);
                    setCoreintelTrendActive(hasHealthcareRansomwareTrend);
                    setMedshieldTrendMultiplier(hasHealthcareRansomwareTrend ? 1.15 : 1);
                }
            }["Page.useEffect"]);
            return ({
                "Page.useEffect": ()=>{
                    active = false;
                }
            })["Page.useEffect"];
        }
    }["Page.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            if (regulatoryState.vendorRegulatoryFeed.length === 0) {
                return;
            }
            const previous = previousVendorStatusRef.current;
            const changedVendors = [];
            for (const item of regulatoryState.vendorRegulatoryFeed){
                const previousStatus = previous.get(item.vendorName);
                if (previousStatus && previousStatus !== item.regulatoryStatus) {
                    changedVendors.push(`${item.vendorName} (${item.source}: ${previousStatus} → ${item.regulatoryStatus})`);
                    if (item.source === "Nth-Party Map" && item.regulatoryStatus === "VIOLATION DETECTED") {
                        const liabilityUsd = 11_100_000;
                        const severityScore = calculateCoreintelSeverity(liabilityUsd);
                        const alertId = `stream-${item.vendorName}-${item.regulatoryStatus}-${regulatoryState.syncedAt ?? Date.now()}`;
                        queueMicrotask({
                            "Page.useEffect": ()=>{
                                setSupplyChainThreat(item.vendorName, liabilityUsd);
                                appendOrchestrationLog(`${new Date().toISOString()} Telemetry // SUPPLY CHAIN VIOLATION routed to Medshield Threat Pipeline for ${item.vendorName}.`);
                                upsertAgentAlert({
                                    id: alertId,
                                    type: "AGENT_ALERT",
                                    origin: "IRONSIGHT",
                                    isExternalSOC: false,
                                    sourceAgent: "IRONSIGHT",
                                    title: `SUPPLY CHAIN VIOLATION // Azure Health`,
                                    impact: "Nth-Party Breach Detected: KubeOps EU-West. Azure Health (Tier 1 Vendor) is now COMPROMISED.",
                                    severityScore,
                                    liabilityUsd,
                                    status: "OPEN",
                                    createdAt: new Date().toISOString()
                                });
                            }
                        }["Page.useEffect"]);
                    }
                }
                previous.set(item.vendorName, item.regulatoryStatus);
            }
            const nextSupplyChainViolation = changedVendors.length > 0 ? `SUPPLY CHAIN VIOLATION // ${changedVendors.join(" // ")}` : null;
            queueMicrotask({
                "Page.useEffect": ()=>{
                    setSupplyChainViolation(nextSupplyChainViolation);
                }
            }["Page.useEffect"]);
        }
    }["Page.useEffect"], [
        regulatoryState.syncedAt,
        regulatoryState.vendorRegulatoryFeed
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            if (!heuristicAnomalyDetectionEnabled) {
                return;
            }
            const recentAlerts = agentStreamAlerts.filter({
                "Page.useEffect.recentAlerts": (alert)=>alert.type !== "ANOMALY"
            }["Page.useEffect.recentAlerts"]).map({
                "Page.useEffect.recentAlerts": (alert)=>({
                        ...alert,
                        timeMs: new Date(alert.createdAt).getTime()
                    })
            }["Page.useEffect.recentAlerts"]).filter({
                "Page.useEffect.recentAlerts": (alert)=>!Number.isNaN(alert.timeMs)
            }["Page.useEffect.recentAlerts"]);
            const bySource = new Map();
            for (const alert of recentAlerts){
                const key = alert.sourceAgent;
                const bucket = bySource.get(key) ?? [];
                bucket.push(alert);
                bySource.set(key, bucket);
            }
            const now = Date.now();
            for (const [source, bucket] of bySource.entries()){
                const inWindow = bucket.sort({
                    "Page.useEffect.inWindow": (a, b)=>b.timeMs - a.timeMs
                }["Page.useEffect.inWindow"]).filter({
                    "Page.useEffect.inWindow": (alert)=>now - alert.timeMs <= 5000
                }["Page.useEffect.inWindow"]);
                if (inWindow.length < 3) {
                    continue;
                }
                const cooldownUntil = anomalyCooldownRef.current.get(source) ?? 0;
                if (cooldownUntil > now) {
                    continue;
                }
                const anomalyId = `anomaly-${source.toLowerCase().replace(/\s+/g, "-")}-${now}`;
                const title = "SYSTEM NOISE ANOMALY";
                const impact = source === "COREINTEL" ? "Coreintel: Risk Score Deviation Detected - $2.1M Variance" : `${source}: Rapid Alert Burst Detected - ${inWindow.length} alerts in < 5 seconds.`;
                queueMicrotask({
                    "Page.useEffect": ()=>{
                        upsertAgentAlert({
                            id: anomalyId,
                            type: "ANOMALY",
                            origin: "SYSTEM",
                            isExternalSOC: false,
                            sourceAgent: "IRONSIGHT",
                            title,
                            impact,
                            severityScore: 82,
                            liabilityUsd: 2_100_000,
                            status: "OPEN",
                            createdAt: new Date(now).toISOString()
                        });
                        appendOrchestrationLog(`${new Date(now).toISOString()} SYSTEM NOISE ANOMALY // source=${source} count=${inWindow.length} window=<5s`);
                    }
                }["Page.useEffect"]);
                anomalyCooldownRef.current.set(source, now + 5000);
                break;
            }
        }
    }["Page.useEffect"], [
        agentStreamAlerts,
        heuristicAnomalyDetectionEnabled
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            const unresponsiveRequests = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$mailHub$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUnresponsiveVendorRequests"])();
            for (const request of unresponsiveRequests){
                const vendorName = request.vendorName ?? "UNKNOWN VENDOR";
                const alertId = `unresponsive-${request.id}`;
                queueMicrotask({
                    "Page.useEffect": ()=>{
                        upsertAgentAlert({
                            id: alertId,
                            type: "AGENT_ALERT",
                            origin: "IRONSIGHT",
                            isExternalSOC: false,
                            sourceAgent: "IRONSIGHT",
                            title: `UNRESPONSIVE VENDOR // ${vendorName}`,
                            impact: `No read receipt detected within 48 hours for document update request (${request.recipientEmail}).`,
                            severityScore: 88,
                            liabilityUsd: 1_250_000,
                            status: "OPEN",
                            createdAt: new Date().toISOString()
                        });
                    }
                }["Page.useEffect"]);
            }
        }
    }["Page.useEffect"], [
        mailHubState.outbound
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            for (const mail of mailHubState.outbound){
                if (mail.channel !== "CADENCE_30_STAKEHOLDER") {
                    continue;
                }
                if (processedCadenceDispatchIdsRef.current.has(mail.id)) {
                    continue;
                }
                processedCadenceDispatchIdsRef.current.add(mail.id);
                queueMicrotask({
                    "Page.useEffect": ()=>{
                        upsertAgentAlert({
                            id: `cadence-dispatch-${mail.id}`,
                            type: "AGENT_ALERT",
                            origin: "IRONSIGHT",
                            isExternalSOC: false,
                            sourceAgent: "IRONSIGHT",
                            title: "CISO/LEGAL ESCALATION DISPATCH CONFIRMED",
                            impact: `30-day escalation sent for ${mail.vendorName ?? "vendor"} to ${mail.recipientTitle} (${mail.recipientEmail}).`,
                            severityScore: 74,
                            liabilityUsd: 350000,
                            status: "OPEN",
                            createdAt: mail.sentAt
                        });
                    }
                }["Page.useEffect"]);
            }
        }
    }["Page.useEffect"], [
        mailHubState.outbound
    ]);
    const remediateSupplyChainThreat = (vendorName)=>{
        const alertId = `pipeline-remediate-${vendorName.toLowerCase().replace(/\s+/g, "-")}`;
        setCoreintelLiveFeed((current)=>[
                `[COREGUARD] Vendor Breach Response playbook launched for ${vendorName}.`,
                ...current
            ].slice(0, 20));
        setAgentStreamAlerts((current)=>{
            if (current.some((alert)=>alert.id === alertId)) {
                return current;
            }
            return [
                {
                    id: alertId,
                    type: "AGENT_ALERT",
                    origin: "SYSTEM",
                    isExternalSOC: false,
                    sourceAgent: "IRONSIGHT",
                    title: "Vendor Breach Response Playbook Initiated",
                    impact: `Coreguard opened Vendor Breach Response playbook for ${vendorName}.`,
                    severityScore: 93,
                    liabilityUsd: 11_100_000,
                    status: "APPROVED",
                    createdAt: new Date().toISOString()
                },
                ...current
            ].slice(0, 20);
        });
    };
    const approveRemediation = (alertId)=>{
        setAgentStreamAlerts((current)=>current.map((alert)=>alert.id === alertId ? {
                    ...alert,
                    status: "APPROVED"
                } : alert));
        setAgentStreamAlerts((current)=>{
            const source = current.find((alert)=>alert.id === alertId);
            if (!source) {
                return current;
            }
            const playbookAlertId = `${alertId}-coreguard-playbook`;
            if (current.some((alert)=>alert.id === playbookAlertId)) {
                return current;
            }
            return [
                {
                    id: playbookAlertId,
                    type: "AGENT_ALERT",
                    origin: "SYSTEM",
                    isExternalSOC: false,
                    sourceAgent: "IRONSIGHT",
                    title: "Remediation Playbook Initiated",
                    impact: `Coreguard launched containment and vendor isolation playbook for ${source.title.replace("Nth-Party Breach Detected: ", "")}.`,
                    severityScore: source.severityScore,
                    liabilityUsd: source.liabilityUsd,
                    status: "APPROVED",
                    createdAt: new Date().toISOString()
                },
                ...current
            ].slice(0, 20);
        });
        setCoreintelLiveFeed((current)=>[
                `[COREGUARD] Playbook execution started for ${alertId}.`,
                ...current
            ].slice(0, 20));
    };
    const dismissAlert = async (alertId)=>{
        setAgentStreamAlerts((current)=>current.map((alert)=>alert.id === alertId ? {
                    ...alert,
                    status: "DISMISSED"
                } : alert));
        setCoreintelLiveFeed((current)=>[
                `[COREINTEL] Risk acceptance recorded for ${alertId}.`,
                ...current
            ].slice(0, 20));
        await fetch("/api/audit/risk-acceptance", {
            method: "POST",
            headers: {
                "content-type": "application/json"
            },
            body: JSON.stringify({
                alertId,
                actor: "SECURITY_ANALYST",
                reason: "Operator dismissed remediation recommendation and accepted risk exposure."
            })
        }).catch(()=>null);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            let active = true;
            const runHeartbeat = {
                "Page.useEffect.runHeartbeat": async ()=>{
                    try {
                        const [healthResponse, assetsResponse] = await Promise.all([
                            fetch("/api/health", {
                                cache: "no-store"
                            }),
                            fetch("/api/medshield/assets", {
                                cache: "no-store"
                            })
                        ]);
                        if (!active) {
                            return;
                        }
                        const hasFailure = !healthResponse.ok || !assetsResponse.ok || Boolean(regulatoryState.error);
                        setHeartbeatFailure(hasFailure);
                        setPhoneHomeAlert(hasFailure ? "CRITICAL: AGENT MANAGER PHONING HOME" : null);
                    } catch (_error) {
                        if (!active) {
                            return;
                        }
                        setHeartbeatFailure(true);
                        setPhoneHomeAlert("CRITICAL: AGENT MANAGER PHONING HOME");
                    }
                }
            }["Page.useEffect.runHeartbeat"];
            void runHeartbeat();
            const interval = setInterval({
                "Page.useEffect.interval": ()=>{
                    void runHeartbeat();
                }
            }["Page.useEffect.interval"], 15000);
            return ({
                "Page.useEffect": ()=>{
                    active = false;
                    clearInterval(interval);
                }
            })["Page.useEffect"];
        }
    }["Page.useEffect"], [
        regulatoryState.error
    ]);
    const agentHealth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Page.useMemo[agentHealth]": ()=>{
            if (heartbeatFailure) {
                return {
                    agentManager: "CRITICAL",
                    ironsight: "DEGRADED",
                    coreintel: "DEGRADED"
                };
            }
            return {
                agentManager: "HEALTHY",
                ironsight: supplyChainViolation ? "CRITICAL" : "HEALTHY",
                coreintel: coreintelTrendActive ? "HEALTHY" : "HEALTHY"
            };
        }
    }["Page.useMemo[agentHealth]"], [
        coreintelTrendActive,
        heartbeatFailure,
        supplyChainViolation
    ]);
    const applyRemediatedAssets = (entityKey)=>{
        const source = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTITY_SCORING_DATA"][entityKey];
        return {
            ...source,
            assets: source.assets.map((asset)=>remediationState.remediatedAssetIds.includes(asset.id) ? {
                    ...asset,
                    status: "SECURE"
                } : asset)
        };
    };
    const medshieldQuestionnaireThreats = vendorAssessments.filter((entry)=>entry.entityKey === "medshield" && !entry.mfaEnabled).length;
    const vaultbankQuestionnaireThreats = vendorAssessments.filter((entry)=>entry.entityKey === "vaultbank" && !entry.mfaEnabled).length;
    const gridcoreQuestionnaireThreats = vendorAssessments.filter((entry)=>entry.entityKey === "gridcore" && !entry.mfaEnabled).length;
    const adjustedEntities = [
        {
            ...applyRemediatedAssets("medshield"),
            activeThreats: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTITY_SCORING_DATA"].medshield.activeThreats + medshieldQuestionnaireThreats
        },
        {
            ...applyRemediatedAssets("vaultbank"),
            activeThreats: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTITY_SCORING_DATA"].vaultbank.activeThreats + vaultbankQuestionnaireThreats
        },
        {
            ...applyRemediatedAssets("gridcore"),
            activeThreats: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTITY_SCORING_DATA"].gridcore.activeThreats + gridcoreQuestionnaireThreats
        }
    ];
    const aggregateEntityData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildAggregateEntityData"])(adjustedEntities);
    const questionnaireImpact = vendorAssessments.reduce((sum, entry)=>sum + entry.potentialFinancialImpact, 0);
    const medshieldExposure = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateFinancialExposure"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTITY_FINANCIAL_FACTORS"].medshield) * medshieldTrendMultiplier;
    const potentialRevenueImpact = medshieldExposure + (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateFinancialExposure"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTITY_FINANCIAL_FACTORS"].vaultbank) + (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateFinancialExposure"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENTITY_FINANCIAL_FACTORS"].gridcore) + questionnaireImpact - (remediationState.riskReductionByEntity.medshield + remediationState.riskReductionByEntity.vaultbank + remediationState.riskReductionByEntity.gridcore);
    const aggregateScore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$scoring$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateEntityScore"])(aggregateEntityData);
    const activeViolations = aggregateScore.criticalAssets + aggregateScore.vulnerableAssets + aggregateScore.activeThreats;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex h-full overflow-hidden bg-slate-950",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                className: "w-80 shrink-0 overflow-y-auto border-r border-slate-800 bg-slate-950",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$StrategicIntel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    agentHealth: agentHealth,
                    phoneHomeAlert: phoneHomeAlert,
                    coreintelLiveFeed: coreintelLiveFeed
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 572,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 571,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "flex min-w-0 flex-1 flex-col overflow-y-auto border-r border-slate-800 bg-slate-950 p-0",
                children: [
                    phoneHomeAlert && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-b border-red-500/60 bg-red-500/15 px-4 py-2 text-[10px] font-bold uppercase tracking-wide text-red-300",
                        children: [
                            phoneHomeAlert,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "mailto:support@ironframe.local",
                                className: "ml-2 underline text-red-200",
                                children: "Contact Support"
                            }, void 0, false, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 583,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 581,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-b border-slate-800 bg-slate-900/50 px-4 py-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2 text-[10px]",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "rounded border border-red-500/70 bg-red-500/15 px-2 py-0.5 font-bold uppercase tracking-wide text-red-300",
                                    children: "REGULATORY ALERT"
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 591,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "min-w-0 flex-1 overflow-hidden",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "whitespace-nowrap text-slate-200",
                                        children: regulatoryState.ticker.length > 0 ? regulatoryState.ticker.join("  //  ") : regulatoryState.isSyncing ? "Syncing regulatory feed..." : "No new regulatory alerts."
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 595,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 594,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 590,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 589,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-b border-slate-800 bg-slate-950 p-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "group relative flex min-h-44 flex-col justify-between rounded-xl border border-slate-800 bg-slate-900/60 p-6 transition-all hover:border-blue-500/60",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/vendors",
                                    "aria-label": "Open Global Vendor Intelligence",
                                    className: "absolute inset-0 z-10"
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 608,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[10px] font-bold uppercase tracking-wide text-white",
                                    children: "SUPPLY CHAIN HEALTH"
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 609,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-1 flex-col items-center justify-center text-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-[10px] font-bold uppercase tracking-wide text-slate-400",
                                            children: "GLOBAL RATING"
                                        }, void 0, false, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 612,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$HealthScoreBadge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            entityData: aggregateEntityData,
                                            scoreClassName: "text-5xl [text-shadow:0_0_16px_rgba(16,185,129,0.35)]"
                                        }, void 0, false, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 613,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 611,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-end",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col items-end gap-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "rounded border border-red-500 bg-red-500/20 px-2 py-1 text-[9px] font-bold uppercase text-red-500 animate-pulse",
                                                children: [
                                                    activeViolations,
                                                    " ACTIVE VIOLATION",
                                                    activeViolations === 1 ? "" : "S"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/page.tsx",
                                                lineNumber: 621,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/vendors/portal",
                                                className: "relative z-20 rounded border border-slate-700 bg-slate-900 px-2 py-1 text-[9px] font-bold uppercase text-slate-200 hover:border-blue-500 hover:text-blue-300",
                                                children: "Open Vendor Portal"
                                            }, void 0, false, {
                                                fileName: "[project]/app/page.tsx",
                                                lineNumber: 624,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "rounded border border-blue-500/60 bg-blue-500/15 px-2 py-1 text-[9px] font-bold uppercase text-blue-300",
                                                children: [
                                                    "POTENTIAL REVENUE IMPACT: $",
                                                    potentialRevenueImpact.toLocaleString()
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/page.tsx",
                                                lineNumber: 630,
                                                columnNumber: 17
                                            }, this),
                                            coreintelTrendActive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "rounded border border-amber-500/70 bg-amber-500/10 px-2 py-1 text-[9px] font-bold uppercase text-amber-300",
                                                children: "COREINTEL ADJUSTMENT: MEDSHIELD AT-RISK REVENUE +15%"
                                            }, void 0, false, {
                                                fileName: "[project]/app/page.tsx",
                                                lineNumber: 634,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 620,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 619,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 607,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 606,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "border-b border-slate-800 bg-slate-900/35 px-4 py-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-2 flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-[11px] font-bold uppercase tracking-wide text-white",
                                        children: "RECENT VENDOR SUBMISSIONS"
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 645,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[9px] uppercase text-slate-400",
                                        children: "Historical Audit Trail"
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 646,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 644,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "overflow-x-auto rounded border border-slate-800",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                    className: "w-full text-[10px] text-slate-200",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                            className: "border-b border-slate-800 bg-slate-950/80",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        className: "px-3 py-2 text-left font-bold uppercase tracking-wide text-slate-300",
                                                        children: "VENDOR"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/page.tsx",
                                                        lineNumber: 653,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        className: "px-3 py-2 text-left font-bold uppercase tracking-wide text-slate-300",
                                                        children: "SUBMISSION DATE"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/page.tsx",
                                                        lineNumber: 654,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        className: "px-3 py-2 text-left font-bold uppercase tracking-wide text-slate-300",
                                                        children: "AUDITOR"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/page.tsx",
                                                        lineNumber: 655,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        className: "px-3 py-2 text-left font-bold uppercase tracking-wide text-slate-300",
                                                        children: "PREVIOUS SCORE"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/page.tsx",
                                                        lineNumber: 656,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        className: "px-3 py-2 text-left font-bold uppercase tracking-wide text-slate-300",
                                                        children: "NEW SCORE"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/page.tsx",
                                                        lineNumber: 657,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        className: "px-3 py-2 text-left font-bold uppercase tracking-wide text-slate-300",
                                                        children: "CHANGE"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/page.tsx",
                                                        lineNumber: 658,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/page.tsx",
                                                lineNumber: 652,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 651,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                            children: recentSubmissions.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                className: "border-b border-slate-800 bg-slate-900/20",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    colSpan: 6,
                                                    className: "px-3 py-3 text-center text-[10px] text-slate-400",
                                                    children: "No submissions recorded yet."
                                                }, void 0, false, {
                                                    fileName: "[project]/app/page.tsx",
                                                    lineNumber: 664,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/page.tsx",
                                                lineNumber: 663,
                                                columnNumber: 19
                                            }, this) : recentSubmissions.map((submission)=>{
                                                const isPositive = submission.scoreChange >= 0;
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    className: "border-b border-slate-800 bg-slate-900/20",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "px-3 py-2 font-semibold text-white",
                                                            children: submission.vendorName
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/page.tsx",
                                                            lineNumber: 674,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "px-3 py-2 text-slate-300",
                                                            children: new Date(submission.createdAt).toISOString().slice(0, 10)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/page.tsx",
                                                            lineNumber: 675,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "px-3 py-2 text-slate-300",
                                                            children: submission.auditor
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/page.tsx",
                                                            lineNumber: 676,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "px-3 py-2 text-slate-300",
                                                            children: submission.previousScore
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/page.tsx",
                                                            lineNumber: 677,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "px-3 py-2 text-slate-300",
                                                            children: submission.score
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/page.tsx",
                                                            lineNumber: 678,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "px-3 py-2",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: `inline-flex rounded border px-2 py-0.5 text-[9px] font-bold ${isPositive ? "border-emerald-500/70 bg-emerald-500/15 text-emerald-300" : "border-red-500/70 bg-red-500/15 text-red-300"}`,
                                                                children: isPositive ? `+${submission.scoreChange}` : submission.scoreChange
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/page.tsx",
                                                                lineNumber: 680,
                                                                columnNumber: 27
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/page.tsx",
                                                            lineNumber: 679,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, submission.id, true, {
                                                    fileName: "[project]/app/page.tsx",
                                                    lineNumber: 673,
                                                    columnNumber: 23
                                                }, this);
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 661,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 650,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 649,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 643,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ThreatPipeline$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        supplyChainThreat: pipelineSupplyChainThreat,
                        showSocStream: Boolean(systemConfig.socDepartmentEmail.trim()),
                        onRemediateSupplyChainThreat: remediateSupplyChainThreat
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 699,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ActiveRisks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 704,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 579,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                className: "w-80 shrink-0 overflow-y-auto bg-slate-950 p-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$AgentStream$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        alerts: agentStreamAlerts,
                        socIntakeEnabled: systemConfig.socEmailIntakeEnabled,
                        onApprove: approveRemediation,
                        onDismiss: dismissAlert
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 708,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$AuditIntelligence$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 714,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 707,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 570,
        columnNumber: 5
    }, this);
}
_s(Page, "Y512fLM2I8MZ/x0QNzwRUKmul+U=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$vendorQuestionnaireStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVendorAssessmentStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$remediationStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRemediationStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$regulatoryStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRegulatoryStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$systemConfigStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSystemConfigStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$mailHubStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMailHubStore"]
    ];
});
_c = Page;
var _c;
__turbopack_context__.k.register(_c, "Page");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_021bf79c._.js.map