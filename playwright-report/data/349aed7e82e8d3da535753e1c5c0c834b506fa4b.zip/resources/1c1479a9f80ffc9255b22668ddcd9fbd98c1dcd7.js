(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/components/NotificationHub.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NotificationHub
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
const RISK_PRIORITY = {
    CRITICAL: 3,
    HIGH: 2,
    LOW: 1
};
function getRiskClasses(riskTier) {
    if (riskTier === "CRITICAL") {
        return "border-red-500/60 bg-red-500/15 text-red-100";
    }
    if (riskTier === "HIGH") {
        return "border-amber-500/60 bg-amber-500/15 text-amber-100";
    }
    return "border-emerald-500/50 bg-emerald-500/10 text-emerald-100";
}
function resolveAlertPriority(alert, riskTier) {
    if (riskTier === "CRITICAL" || riskTier === "HIGH") {
        return "HIGH";
    }
    const source = alert.source.toLowerCase();
    if (source.includes("informational") || source.includes("info")) {
        return "INFORMATIONAL";
    }
    return "LOW";
}
function NotificationHub({ alerts, resolveRiskTier, onApprove, onReject, onArchiveLowPriority }) {
    _s();
    const sortedAlerts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "NotificationHub.useMemo[sortedAlerts]": ()=>alerts.slice().sort({
                "NotificationHub.useMemo[sortedAlerts]": (left, right)=>{
                    const riskDiff = RISK_PRIORITY[resolveRiskTier(right.vendorName)] - RISK_PRIORITY[resolveRiskTier(left.vendorName)];
                    if (riskDiff !== 0) {
                        return riskDiff;
                    }
                    return right.discoveredAt.localeCompare(left.discoveredAt);
                }
            }["NotificationHub.useMemo[sortedAlerts]"])
    }["NotificationHub.useMemo[sortedAlerts]"], [
        alerts,
        resolveRiskTier
    ]);
    const lowPriorityAlertIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "NotificationHub.useMemo[lowPriorityAlertIds]": ()=>sortedAlerts.filter({
                "NotificationHub.useMemo[lowPriorityAlertIds]": (alert)=>{
                    const riskTier = resolveRiskTier(alert.vendorName);
                    const priority = resolveAlertPriority(alert, riskTier);
                    return priority === "LOW" || priority === "INFORMATIONAL";
                }
            }["NotificationHub.useMemo[lowPriorityAlertIds]"]).map({
                "NotificationHub.useMemo[lowPriorityAlertIds]": (alert)=>alert.id
            }["NotificationHub.useMemo[lowPriorityAlertIds]"])
    }["NotificationHub.useMemo[lowPriorityAlertIds]"], [
        resolveRiskTier,
        sortedAlerts
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-4 rounded border border-slate-800 bg-slate-950/40 px-3 py-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-2 flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-[10px] font-bold uppercase tracking-wide text-slate-200",
                        children: "Permission Required"
                    }, void 0, false, {
                        fileName: "[project]/app/components/NotificationHub.tsx",
                        lineNumber: 79,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "data-testid": "notification-badge-count",
                        className: "inline-flex h-5 min-w-5 items-center justify-center rounded-full border border-red-400/80 bg-red-500 px-1 text-[9px] font-bold text-white",
                        children: sortedAlerts.length
                    }, void 0, false, {
                        fileName: "[project]/app/components/NotificationHub.tsx",
                        lineNumber: 80,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/NotificationHub.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this),
            sortedAlerts.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-testid": "notification-horizontal-bar",
                className: "flex flex-row gap-2 overflow-x-auto py-2 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden",
                children: [
                    sortedAlerts.map((alert)=>{
                        const riskTier = resolveRiskTier(alert.vendorName);
                        const isHighPriority = riskTier === "CRITICAL" || riskTier === "HIGH";
                        const priority = resolveAlertPriority(alert, riskTier);
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `min-w-[190px] rounded border px-2 py-1 text-left text-[9px] ${getRiskClasses(riskTier)} ${isHighPriority ? "animate-pulse" : ""}`,
                            "data-testid": "notification-alert-item",
                            "data-risk-tier": riskTier,
                            "data-priority": priority,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-start justify-between gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "min-w-0 pr-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "font-bold uppercase tracking-tight leading-tight",
                                                children: [
                                                    "Permission Required // ",
                                                    riskTier
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/components/NotificationHub.tsx",
                                                lineNumber: 108,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "leading-tight break-words",
                                                children: [
                                                    alert.vendorName,
                                                    " • ",
                                                    alert.documentType
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/components/NotificationHub.tsx",
                                                lineNumber: 109,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/NotificationHub.tsx",
                                        lineNumber: 107,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex shrink-0 flex-col items-end gap-0.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>onApprove(alert),
                                                className: "rounded border border-blue-500/70 bg-blue-500/20 px-1 py-0 text-[8px] font-bold uppercase tracking-tight text-blue-200",
                                                children: "Approve"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/NotificationHub.tsx",
                                                lineNumber: 112,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>onReject(alert.id),
                                                className: "rounded border border-slate-700 bg-slate-900 px-1 py-0 text-[8px] font-bold uppercase tracking-tight text-slate-200",
                                                children: "Reject"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/NotificationHub.tsx",
                                                lineNumber: 119,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/NotificationHub.tsx",
                                        lineNumber: 111,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/NotificationHub.tsx",
                                lineNumber: 106,
                                columnNumber: 17
                            }, this)
                        }, alert.id, false, {
                            fileName: "[project]/app/components/NotificationHub.tsx",
                            lineNumber: 99,
                            columnNumber: 15
                        }, this);
                    }),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>onArchiveLowPriority(lowPriorityAlertIds),
                        disabled: lowPriorityAlertIds.length === 0,
                        className: "min-w-[170px] rounded border border-slate-700 bg-slate-950 px-2 py-1 text-[8px] font-bold uppercase tracking-tight text-slate-200 hover:border-blue-500 disabled:cursor-not-allowed disabled:opacity-50",
                        "data-testid": "archive-low-priority",
                        children: "Archive All Low-Priority"
                    }, void 0, false, {
                        fileName: "[project]/app/components/NotificationHub.tsx",
                        lineNumber: 132,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/NotificationHub.tsx",
                lineNumber: 89,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-[10px] text-slate-400",
                children: "No active permission-required notices."
            }, void 0, false, {
                fileName: "[project]/app/components/NotificationHub.tsx",
                lineNumber: 143,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/NotificationHub.tsx",
        lineNumber: 77,
        columnNumber: 5
    }, this);
}
_s(NotificationHub, "sk/vNMF3/e4ZgH4EKJepr+Px8MM=");
_c = NotificationHub;
var _c;
__turbopack_context__.k.register(_c, "NotificationHub");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/auditLogger.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "appendAuditLog",
    ()=>appendAuditLog,
    "ensureLoginAuditEvent",
    ()=>ensureLoginAuditEvent,
    "getAuditLogSnapshot",
    ()=>getAuditLogSnapshot,
    "getAuditLogs",
    ()=>getAuditLogs,
    "hydrateAuditLogger",
    ()=>hydrateAuditLogger,
    "purgeExpiredAuditLogs",
    ()=>purgeExpiredAuditLogs,
    "subscribeAuditLogger",
    ()=>subscribeAuditLogger
]);
const AUDIT_LOG_STORAGE_KEY = "ironframe-audit-intelligence-log-v1";
const DEFAULT_USER_ID = "Dereck";
const DEFAULT_IP = "127.0.0.1";
const listeners = new Set();
let auditLogState = Object.freeze([]);
function deepFreezeLog(record) {
    return Object.freeze({
        id: record.id ?? `audit-${record.timestamp}-${Math.random().toString(36).slice(2, 8)}`,
        timestamp: record.timestamp,
        user_id: record.user_id,
        action_type: record.action_type,
        log_type: record.log_type,
        metadata_tag: record.metadata_tag,
        description: record.description,
        ip_address: record.ip_address
    });
}
function emitChange() {
    listeners.forEach((listener)=>listener());
}
function persistAuditLogState() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    window.localStorage.setItem(AUDIT_LOG_STORAGE_KEY, JSON.stringify(auditLogState));
}
function hydrateAuditLogger() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const raw = window.localStorage.getItem(AUDIT_LOG_STORAGE_KEY);
        if (!raw) {
            return;
        }
        const parsed = JSON.parse(raw);
        const safeLogs = parsed.filter((entry)=>Boolean(entry?.timestamp) && Boolean(entry?.description) && Boolean(entry?.action_type)).map((entry)=>deepFreezeLog({
                id: entry.id,
                timestamp: String(entry.timestamp),
                user_id: String(entry.user_id ?? DEFAULT_USER_ID),
                action_type: entry.action_type,
                log_type: entry.log_type ?? "APP_SYSTEM",
                metadata_tag: entry.metadata_tag ? String(entry.metadata_tag) : null,
                description: String(entry.description),
                ip_address: String(entry.ip_address ?? DEFAULT_IP)
            }));
        auditLogState = Object.freeze(safeLogs);
        emitChange();
    } catch (error) {
        console.error("AUDIT_LOGGER_HYDRATE_FAILED", error);
    }
}
function appendAuditLog(input) {
    const timestamp = input.timestamp ?? new Date().toISOString();
    const nextRecord = deepFreezeLog({
        timestamp,
        user_id: input.user_id ?? DEFAULT_USER_ID,
        action_type: input.action_type,
        log_type: input.log_type ?? "APP_SYSTEM",
        metadata_tag: input.metadata_tag ?? null,
        description: input.description,
        ip_address: input.ip_address ?? DEFAULT_IP
    });
    auditLogState = Object.freeze([
        nextRecord,
        ...auditLogState
    ].slice(0, 2000));
    persistAuditLogState();
    emitChange();
    return nextRecord;
}
function ensureLoginAuditEvent() {
    const todayKey = new Date().toISOString().slice(0, 10);
    const hasLoginToday = auditLogState.some((entry)=>entry.action_type === "LOGIN" && entry.timestamp.slice(0, 10) === todayKey);
    if (hasLoginToday) {
        return;
    }
    appendAuditLog({
        action_type: "LOGIN",
        description: "User session authenticated."
    });
}
function purgeExpiredAuditLogs(ttlDays, nowMs = Date.now()) {
    const ttlMs = ttlDays * 24 * 60 * 60 * 1000;
    const beforeCount = auditLogState.length;
    const grcBeforeCount = auditLogState.filter((entry)=>entry.log_type === "GRC").length;
    const retained = auditLogState.filter((entry)=>{
        if (entry.log_type === "GRC") {
            return true;
        }
        const ageMs = nowMs - new Date(entry.timestamp).getTime();
        return !Number.isNaN(ageMs) && ageMs <= ttlMs;
    });
    const grcAfterCount = retained.filter((entry)=>entry.log_type === "GRC").length;
    auditLogState = Object.freeze(retained);
    persistAuditLogState();
    emitChange();
    return {
        beforeCount,
        afterCount: retained.length,
        purgedCount: beforeCount - retained.length,
        grcBeforeCount,
        grcAfterCount,
        grcPurgedCount: grcBeforeCount - grcAfterCount
    };
}
function getAuditLogSnapshot() {
    return auditLogState;
}
function getAuditLogs() {
    return auditLogState.slice(0, 2000);
}
function subscribeAuditLogger(listener) {
    listeners.add(listener);
    return ()=>listeners.delete(listener);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/hooks/useVendorActions.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useVendorActions",
    ()=>useVendorActions
]);
"use client";
const INTERNAL_OWNER_EMAIL_BY_ENTITY = {
    MEDSHIELD: "medshield-owner@ironframe.local",
    VAULTBANK: "vaultbank-owner@ironframe.local",
    GRIDCORE: "gridcore-owner@ironframe.local"
};
function useVendorActions(stakeholders, vendorTypeRequirements) {
    const resolveInternalStakeholderEmail = (associatedEntity)=>{
        const normalizedEntity = associatedEntity.trim().toUpperCase();
        const matchedStakeholder = stakeholders.find((stakeholder)=>{
            if (!stakeholder.email.trim()) {
                return false;
            }
            const title = stakeholder.title.toLowerCase();
            const department = stakeholder.department.toLowerCase();
            const name = stakeholder.name.toLowerCase();
            const entityLower = normalizedEntity.toLowerCase();
            return title.includes(entityLower) || department.includes(entityLower) || name.includes(entityLower);
        });
        if (matchedStakeholder?.email.trim()) {
            return matchedStakeholder.email.trim();
        }
        return INTERNAL_OWNER_EMAIL_BY_ENTITY[normalizedEntity] || "grc-operations@ironframe.local";
    };
    const buildDocumentGapSummary = (context)=>{
        const requiredDocuments = vendorTypeRequirements[context.vendorType] ?? [
            "SOC2"
        ];
        const missingDocuments = requiredDocuments.filter((documentName)=>!context.evidenceLockerDocs.includes(documentName));
        const normalizedMissing = missingDocuments.map((documentName)=>documentName === "ISO 27001" ? "Pending ISO 27001 renewal" : `Missing ${documentName}`);
        const documentGaps = [
            ...context.soc2Status === "Expired" ? [
                `Expired SOC2 (${context.soc2ExpirationDate})`
            ] : [],
            ...normalizedMissing
        ];
        return documentGaps.length > 0 ? documentGaps.join("; ") : "No critical gaps detected";
    };
    return {
        resolveInternalStakeholderEmail,
        vendorProfiles: vendorTypeRequirements,
        buildDocumentGapSummary
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/store/systemConfigStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_VENDOR_EVIDENCE_REQUEST_TEMPLATE",
    ()=>DEFAULT_VENDOR_EVIDENCE_REQUEST_TEMPLATE,
    "getSystemConfigSnapshot",
    ()=>getSystemConfigSnapshot,
    "hydrateSystemConfig",
    ()=>hydrateSystemConfig,
    "setAdhocNotificationGroups",
    ()=>setAdhocNotificationGroups,
    "setAuthorizedSocDomains",
    ()=>setAuthorizedSocDomains,
    "setCadenceAlerts",
    ()=>setCadenceAlerts,
    "setCompanyStakeholders",
    ()=>setCompanyStakeholders,
    "setGeneralRfiChecklist",
    ()=>setGeneralRfiChecklist,
    "setSocAutoReceiptEnabled",
    ()=>setSocAutoReceiptEnabled,
    "setSocDepartmentEmail",
    ()=>setSocDepartmentEmail,
    "setSocEmailIntakeEnabled",
    ()=>setSocEmailIntakeEnabled,
    "setVendorDocumentUpdateTemplate",
    ()=>setVendorDocumentUpdateTemplate,
    "setVendorTypeRequirements",
    ()=>setVendorTypeRequirements,
    "subscribeSystemConfig",
    ()=>subscribeSystemConfig,
    "useSystemConfigStore",
    ()=>useSystemConfigStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/auditLogger.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const DEFAULT_VENDOR_EVIDENCE_REQUEST_TEMPLATE = "NIST 800-53 Evidence Request: Please provide updated control evidence, attestation artifacts, and remediation status for your assigned controls within 48 hours.";
const STORAGE_KEY = "ironframe-system-config-v1";
const listeners = new Set();
const DEFAULT_STAKEHOLDERS = [
    {
        id: "stakeholder-1",
        name: "",
        title: "CISO",
        email: "",
        department: "Security",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-2",
        name: "",
        title: "CRO",
        email: "",
        department: "Risk",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-3",
        name: "",
        title: "DPO",
        email: "",
        department: "Privacy",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-4",
        name: "",
        title: "CFO",
        email: "",
        department: "Finance",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-5",
        name: "",
        title: "General Counsel",
        email: "",
        department: "Legal",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-6",
        name: "",
        title: "Head of ITSM",
        email: "",
        department: "IT Operations",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-7",
        name: "",
        title: "Head of Product Security",
        email: "",
        department: "Product Security",
        includeReadReceipt: false,
        readReceiptLog: []
    },
    {
        id: "stakeholder-8",
        name: "",
        title: "Audit Director",
        email: "",
        department: "Internal Audit",
        includeReadReceipt: false,
        readReceiptLog: []
    }
];
const DEFAULT_ADHOC_GROUPS = [
    {
        id: "group-1",
        name: "",
        emails: "",
        includeReadReceipt: false
    },
    {
        id: "group-2",
        name: "",
        emails: "",
        includeReadReceipt: false
    },
    {
        id: "group-3",
        name: "",
        emails: "",
        includeReadReceipt: false
    }
];
const DEFAULT_GENERAL_RFI_CHECKLIST = [
    "Privacy Policy",
    "Insurance",
    "Pen Test",
    "Disaster Recovery"
];
const DEFAULT_VENDOR_TYPE_REQUIREMENTS = {
    SaaS: [
        "SOC2",
        "Privacy Policy"
    ],
    "On-Prem Software": [
        "ISO 27001",
        "Vulnerability Scan Report"
    ],
    "Managed Services": [
        "SOC2",
        "Business Continuity Plan",
        "Incident Response Plan"
    ],
    Hardware: [
        "NIST 800-161",
        "ISO 9001"
    ]
};
let systemConfigState = {
    socEmailIntakeEnabled: false,
    socDepartmentEmail: "",
    socAutoReceiptEnabled: false,
    authorizedSocDomains: [
        "medshield.com"
    ],
    companyStakeholders: DEFAULT_STAKEHOLDERS,
    vendorDocumentUpdateTemplate: DEFAULT_VENDOR_EVIDENCE_REQUEST_TEMPLATE,
    adhocNotificationGroups: DEFAULT_ADHOC_GROUPS,
    cadenceAlerts: {
        day90: true,
        day60: true,
        day30: true
    },
    generalRfiChecklist: DEFAULT_GENERAL_RFI_CHECKLIST,
    vendorTypeRequirements: DEFAULT_VENDOR_TYPE_REQUIREMENTS
};
function emitChange() {
    listeners.forEach((listener)=>listener());
}
function sanitizeDomains(input) {
    return Array.from(new Set(input.map((entry)=>entry.trim().toLowerCase()).filter((entry)=>entry.length > 0).map((entry)=>entry.replace(/^@/, ""))));
}
function sanitizeStakeholders(input) {
    if (!input || input.length === 0) {
        return DEFAULT_STAKEHOLDERS;
    }
    const parsed = input.slice(0, 20).map((stakeholder, index)=>({
            id: stakeholder.id || `stakeholder-${index + 1}`,
            name: stakeholder.name?.trim() ?? "",
            title: stakeholder.title?.trim() ?? "",
            email: stakeholder.email?.trim() ?? "",
            department: stakeholder.department?.trim() ?? "",
            includeReadReceipt: Boolean(stakeholder.includeReadReceipt),
            readReceiptLog: Array.isArray(stakeholder.readReceiptLog) ? stakeholder.readReceiptLog.map((entry)=>String(entry).trim()).filter((entry)=>entry.length > 0) : []
        }));
    return parsed.length >= 8 ? parsed : [
        ...parsed,
        ...DEFAULT_STAKEHOLDERS.slice(parsed.length, 8)
    ];
}
function sanitizeAdhocGroups(input) {
    const fallback = DEFAULT_ADHOC_GROUPS;
    if (!input || input.length === 0) {
        return fallback;
    }
    const parsed = input.slice(0, 3).map((group, index)=>({
            id: group.id || `group-${index + 1}`,
            name: group.name?.trim() ?? "",
            emails: group.emails?.trim() ?? "",
            includeReadReceipt: Boolean(group.includeReadReceipt)
        }));
    while(parsed.length < 3){
        parsed.push(fallback[parsed.length]);
    }
    return parsed;
}
function sanitizeCadenceAlerts(input) {
    return {
        day90: input?.day90 ?? true,
        day60: input?.day60 ?? true,
        day30: input?.day30 ?? true
    };
}
function sanitizeChecklist(input) {
    const parsed = (input ?? []).map((entry)=>entry.trim()).filter((entry)=>entry.length > 0);
    if (parsed.length === 0) {
        return DEFAULT_GENERAL_RFI_CHECKLIST;
    }
    return Array.from(new Set(parsed));
}
function sanitizeVendorTypeRequirements(input) {
    const source = input ?? {};
    return {
        SaaS: sanitizeChecklist(source.SaaS),
        "On-Prem Software": sanitizeChecklist(source["On-Prem Software"]),
        "Managed Services": sanitizeChecklist(source["Managed Services"]),
        Hardware: sanitizeChecklist(source.Hardware)
    };
}
function hydrateSystemConfig() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const raw = window.localStorage.getItem(STORAGE_KEY);
        if (!raw) {
            return;
        }
        const parsed = JSON.parse(raw);
        systemConfigState = {
            socEmailIntakeEnabled: parsed.socEmailIntakeEnabled ?? false,
            socDepartmentEmail: parsed.socDepartmentEmail?.trim() ?? "",
            socAutoReceiptEnabled: parsed.socAutoReceiptEnabled ?? false,
            authorizedSocDomains: sanitizeDomains(parsed.authorizedSocDomains ?? []),
            companyStakeholders: sanitizeStakeholders(parsed.companyStakeholders),
            vendorDocumentUpdateTemplate: parsed.vendorDocumentUpdateTemplate?.trim() || DEFAULT_VENDOR_EVIDENCE_REQUEST_TEMPLATE,
            adhocNotificationGroups: sanitizeAdhocGroups(parsed.adhocNotificationGroups),
            cadenceAlerts: sanitizeCadenceAlerts(parsed.cadenceAlerts),
            generalRfiChecklist: sanitizeChecklist(parsed.generalRfiChecklist),
            vendorTypeRequirements: sanitizeVendorTypeRequirements(parsed.vendorTypeRequirements)
        };
        emitChange();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureLoginAuditEvent"])();
    } catch  {
    // no-op
    }
}
function persistSystemConfig() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(systemConfigState));
}
function subscribeSystemConfig(listener) {
    listeners.add(listener);
    return ()=>listeners.delete(listener);
}
function getSystemConfigSnapshot() {
    return systemConfigState;
}
function setSocEmailIntakeEnabled(enabled) {
    systemConfigState = {
        ...systemConfigState,
        socEmailIntakeEnabled: enabled
    };
    persistSystemConfig();
    emitChange();
}
function setSocDepartmentEmail(email) {
    const value = email.trim();
    systemConfigState = {
        ...systemConfigState,
        socDepartmentEmail: value
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendAuditLog"])({
        action_type: "CONFIG_CHANGE",
        log_type: "GRC",
        metadata_tag: "GRC_GOVERNANCE",
        description: `SOC department email updated to ${value || "(empty)"}.`
    });
    persistSystemConfig();
    emitChange();
}
function setSocAutoReceiptEnabled(enabled) {
    systemConfigState = {
        ...systemConfigState,
        socAutoReceiptEnabled: enabled
    };
    persistSystemConfig();
    emitChange();
}
function setAuthorizedSocDomains(domains) {
    systemConfigState = {
        ...systemConfigState,
        authorizedSocDomains: sanitizeDomains(domains)
    };
    persistSystemConfig();
    emitChange();
}
function setCompanyStakeholders(stakeholders) {
    const sanitized = sanitizeStakeholders(stakeholders);
    systemConfigState = {
        ...systemConfigState,
        companyStakeholders: sanitized
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendAuditLog"])({
        action_type: "CONFIG_CHANGE",
        log_type: "GRC",
        metadata_tag: "GRC_GOVERNANCE",
        description: `Stakeholder table saved (${sanitized.filter((entry)=>entry.email.length > 0).length} email targets configured).`
    });
    persistSystemConfig();
    emitChange();
}
function setVendorDocumentUpdateTemplate(template) {
    const value = template.trim();
    systemConfigState = {
        ...systemConfigState,
        vendorDocumentUpdateTemplate: value
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendAuditLog"])({
        action_type: "CONFIG_CHANGE",
        log_type: "GRC",
        metadata_tag: "GRC_GOVERNANCE",
        description: `Vendor evidence template updated (${value.length} chars).`
    });
    persistSystemConfig();
    emitChange();
}
function setAdhocNotificationGroups(groups) {
    systemConfigState = {
        ...systemConfigState,
        adhocNotificationGroups: sanitizeAdhocGroups(groups)
    };
    persistSystemConfig();
    emitChange();
}
function setCadenceAlerts(cadenceAlerts) {
    systemConfigState = {
        ...systemConfigState,
        cadenceAlerts: sanitizeCadenceAlerts(cadenceAlerts)
    };
    persistSystemConfig();
    emitChange();
}
function setGeneralRfiChecklist(checklist) {
    const sanitized = sanitizeChecklist(checklist);
    systemConfigState = {
        ...systemConfigState,
        generalRfiChecklist: sanitized
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendAuditLog"])({
        action_type: "CONFIG_CHANGE",
        log_type: "GRC",
        metadata_tag: "GRC_GOVERNANCE",
        description: `General RFI checklist updated (${sanitized.length} items).`
    });
    persistSystemConfig();
    emitChange();
}
function setVendorTypeRequirements(requirements) {
    const sanitized = sanitizeVendorTypeRequirements(requirements);
    systemConfigState = {
        ...systemConfigState,
        vendorTypeRequirements: sanitized
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendAuditLog"])({
        action_type: "CONFIG_CHANGE",
        log_type: "GRC",
        metadata_tag: "GRC_GOVERNANCE",
        description: "Vendor type evidence requirements updated."
    });
    persistSystemConfig();
    emitChange();
}
function useSystemConfigStore() {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribeSystemConfig, getSystemConfigSnapshot, getSystemConfigSnapshot);
}
_s(useSystemConfigStore, "FpwL93IKMLJZuQQXefVtWynbBPQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/services/idpService.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "analyzeVendorDocument",
    ()=>analyzeVendorDocument
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
function normalizeDateToken(value) {
    const isoMatch = value.match(/(20\d{2})[-_](0[1-9]|1[0-2])[-_](0[1-9]|[12]\d|3[01])/);
    if (isoMatch) {
        return `${isoMatch[1]}-${isoMatch[2]}-${isoMatch[3]}`;
    }
    const slashMatch = value.match(/(0[1-9]|1[0-2])[\/-](0[1-9]|[12]\d|3[01])[\/-](20\d{2})/);
    if (slashMatch) {
        return `${slashMatch[3]}-${slashMatch[1]}-${slashMatch[2]}`;
    }
    return null;
}
function classifyFromName(fileName) {
    const lower = fileName.toLowerCase();
    if (lower.includes("soc2") || lower.includes("soc-2")) {
        return "SOC2";
    }
    if (lower.includes("iso") || lower.includes("27001")) {
        return "ISO";
    }
    if (lower.includes("insurance") || lower.includes("certificate-of-insurance") || lower.includes("coi")) {
        return "INSURANCE";
    }
    return "UNKNOWN";
}
function inferVendorName(fileName) {
    const cleaned = fileName.replace(/\.[^/.]+$/, "").replace(/(soc2|soc-2|iso|27001|insurance|certificate|coi|attestation|report)/gi, "").replace(/[\W_]+/g, " ").trim();
    if (!cleaned) {
        return "";
    }
    return cleaned.split(" ").filter((token)=>token.length > 0).map((token)=>token.charAt(0).toUpperCase() + token.slice(1).toLowerCase()).join(" ");
}
async function classifyWithAzureBridge(file) {
    const endpoint = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT;
    if (!endpoint) {
        return null;
    }
    try {
        const response = await fetch("/api/idp/classify", {
            method: "POST",
            headers: {
                "x-idp-provider": "azure-document-intelligence",
                "x-file-name": file.name
            },
            body: file
        });
        if (!response.ok) {
            return null;
        }
        const payload = await response.json();
        if (!payload.documentType) {
            return null;
        }
        return {
            documentType: payload.documentType,
            vendorName: payload.vendorName ?? "",
            expirationDate: payload.expirationDate ?? null,
            confidence: payload.confidence ?? 0.85,
            fieldConfidence: {
                vendorName: 0.9,
                documentType: 0.95,
                expirationDate: payload.expirationDate ? 0.9 : 0.4
            },
            provider: "azure-document-intelligence"
        };
    } catch  {
        return null;
    }
}
async function analyzeVendorDocument(file) {
    const azureResult = await classifyWithAzureBridge(file);
    if (azureResult) {
        return azureResult;
    }
    const documentType = classifyFromName(file.name);
    const expirationDate = normalizeDateToken(file.name);
    const vendorName = inferVendorName(file.name);
    return {
        documentType,
        vendorName,
        expirationDate,
        confidence: documentType === "UNKNOWN" ? 0.55 : 0.86,
        fieldConfidence: {
            vendorName: vendorName ? 0.82 : 0.35,
            documentType: documentType === "UNKNOWN" ? 0.58 : 0.92,
            expirationDate: expirationDate ? 0.88 : 0.32
        },
        provider: "heuristic-fallback"
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/vendors/AddVendorModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AddVendorModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$cloud$2d$upload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadCloud$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/cloud-upload.js [app-client] (ecmascript) <export default as UploadCloud>");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$idpService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/idpService.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function AddVendorModal({ isOpen, onClose, onSubmit, vendorTypeRequirements }) {
    _s();
    const [vendorName, setVendorName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [vendorType, setVendorType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("SaaS");
    const [industry, setIndustry] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("Healthcare");
    const [riskTier, setRiskTier] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("HIGH");
    const [documentType, setDocumentType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("UNKNOWN");
    const [expirationDate, setExpirationDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [isAnalyzing, setIsAnalyzing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [uploadFileName, setUploadFileName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [ghostFields, setGhostFields] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: false,
        documentType: false,
        expirationDate: false
    });
    const [fieldConfidence, setFieldConfidence] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const canSubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "AddVendorModal.useMemo[canSubmit]": ()=>vendorName.trim().length > 0
    }["AddVendorModal.useMemo[canSubmit]"], [
        vendorName
    ]);
    const requiredEvidence = vendorTypeRequirements[vendorType] ?? [
        "SOC2"
    ];
    if (!isOpen) {
        return null;
    }
    const applyAnalysis = async (file)=>{
        setIsAnalyzing(true);
        setUploadFileName(file.name);
        try {
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$idpService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["analyzeVendorDocument"])(file);
            if (result.vendorName) {
                setVendorName(result.vendorName);
                setGhostFields((current)=>({
                        ...current,
                        name: true
                    }));
                setFieldConfidence((current)=>({
                        ...current,
                        name: result.fieldConfidence.vendorName
                    }));
            }
            if (result.documentType) {
                setDocumentType(result.documentType);
                setGhostFields((current)=>({
                        ...current,
                        documentType: true
                    }));
                setFieldConfidence((current)=>({
                        ...current,
                        documentType: result.fieldConfidence.documentType
                    }));
            }
            if (result.expirationDate) {
                setExpirationDate(result.expirationDate);
                setGhostFields((current)=>({
                        ...current,
                        expirationDate: true
                    }));
                setFieldConfidence((current)=>({
                        ...current,
                        expirationDate: result.fieldConfidence.expirationDate
                    }));
            }
        } finally{
            setIsAnalyzing(false);
        }
    };
    const handleDrop = async (event)=>{
        event.preventDefault();
        const file = event.dataTransfer.files?.[0];
        if (!file) {
            return;
        }
        await applyAnalysis(file);
    };
    const handleFileChange = async (event)=>{
        const file = event.target.files?.[0];
        if (!file) {
            return;
        }
        await applyAnalysis(file);
    };
    const handleSubmit = ()=>{
        onSubmit({
            vendorName: vendorName.trim(),
            vendorType,
            industry,
            riskTier,
            documentType,
            expirationDate,
            fileName: uploadFileName
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[85] flex justify-end bg-slate-950/70",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-full w-full max-w-md border-l border-slate-800 bg-slate-900 p-4 shadow-2xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-4 flex items-center justify-between border-b border-slate-800 pb-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-[11px] font-bold uppercase tracking-wide text-white",
                            children: "Manual Vendor Ingestion"
                        }, void 0, false, {
                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                            lineNumber: 113,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: onClose,
                            className: "rounded border border-slate-700 bg-slate-950 px-2 py-1 text-[10px] font-bold uppercase text-slate-300",
                            children: "Close"
                        }, void 0, false, {
                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                            lineNumber: 114,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                    lineNumber: 112,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            onDrop: handleDrop,
                            onDragOver: (event)=>event.preventDefault(),
                            className: "rounded border border-dashed border-slate-700 bg-slate-950/60 p-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "flex cursor-pointer items-center gap-2 text-[10px] font-bold uppercase tracking-wide text-slate-300",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$cloud$2d$upload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadCloud$3e$__["UploadCloud"], {
                                            className: "h-4 w-4 text-blue-300"
                                        }, void 0, false, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 130,
                                            columnNumber: 15
                                        }, this),
                                        "Drag & Drop SOC2 / ISO / Insurance PDF",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "file",
                                            accept: ".pdf",
                                            className: "hidden",
                                            onChange: handleFileChange
                                        }, void 0, false, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 132,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 129,
                                    columnNumber: 13
                                }, this),
                                isAnalyzing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-2 flex items-center gap-1 text-[9px] text-blue-200",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                            className: "h-3 w-3 animate-spin"
                                        }, void 0, false, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 136,
                                            columnNumber: 17
                                        }, this),
                                        "IDP analyzing document..."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 135,
                                    columnNumber: 15
                                }, this) : uploadFileName ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-2 text-[9px] text-slate-400",
                                    children: [
                                        "Analyzed: ",
                                        uploadFileName
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 140,
                                    columnNumber: 15
                                }, this) : null
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                            lineNumber: 124,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-300",
                                    children: "Vendor Type"
                                }, void 0, false, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 145,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    "data-testid": "add-vendor-type",
                                    value: vendorType,
                                    onChange: (event)=>setVendorType(event.target.value),
                                    className: "h-8 w-full max-w-[180px] rounded border border-slate-800 bg-slate-950 px-3 pr-7 text-[10px] text-white focus:border-blue-500 focus:outline-none",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "SaaS",
                                            children: "SaaS"
                                        }, void 0, false, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 152,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "On-Prem Software",
                                            children: "On-Prem Software"
                                        }, void 0, false, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 153,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "Managed Services",
                                            children: "Managed Services"
                                        }, void 0, false, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 154,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "Hardware",
                                            children: "Hardware"
                                        }, void 0, false, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 155,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 146,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                            lineNumber: 144,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "rounded border border-slate-800 bg-slate-950/60 p-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mb-1 text-[9px] font-bold uppercase tracking-wide text-slate-300",
                                    children: "Required Evidence"
                                }, void 0, false, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 160,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: "space-y-1",
                                    children: requiredEvidence.map((doc)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            className: "text-[9px] text-slate-400",
                                            children: [
                                                "• ",
                                                doc
                                            ]
                                        }, doc, true, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 163,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 161,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                            lineNumber: 159,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-300",
                                    children: "Name"
                                }, void 0, false, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 169,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    "data-testid": "add-vendor-name",
                                    value: vendorName,
                                    onChange: (event)=>{
                                        setVendorName(event.target.value);
                                        setGhostFields((current)=>({
                                                ...current,
                                                name: false
                                            }));
                                    },
                                    placeholder: "Vendor Name",
                                    className: `h-8 w-full rounded border border-slate-800 px-3 text-[10px] text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-none ${ghostFields.name ? "bg-blue-500/10" : "bg-slate-950"}`
                                }, void 0, false, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 170,
                                    columnNumber: 13
                                }, this),
                                ghostFields.name && fieldConfidence.name !== undefined ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-1 text-[9px] text-blue-200",
                                    children: [
                                        Math.round(fieldConfidence.name * 100),
                                        "% Confident"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 183,
                                    columnNumber: 15
                                }, this) : null
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                            lineNumber: 168,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-300",
                                    children: "Industry"
                                }, void 0, false, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 188,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    "data-testid": "add-vendor-industry",
                                    value: industry,
                                    onChange: (event)=>setIndustry(event.target.value),
                                    className: "h-8 w-full max-w-[180px] rounded border border-slate-800 bg-slate-950 px-3 pr-7 text-[10px] text-white focus:border-blue-500 focus:outline-none",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "Healthcare",
                                            children: "Healthcare"
                                        }, void 0, false, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 195,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "Finance",
                                            children: "Finance"
                                        }, void 0, false, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 196,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "Energy",
                                            children: "Energy"
                                        }, void 0, false, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 197,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 189,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                            lineNumber: 187,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-300",
                                    children: "Initial Risk Tier"
                                }, void 0, false, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 202,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    "data-testid": "add-vendor-risk",
                                    value: riskTier,
                                    onChange: (event)=>setRiskTier(event.target.value),
                                    className: "h-8 w-full max-w-[180px] rounded border border-slate-800 bg-slate-950 px-3 pr-7 text-[10px] text-white focus:border-blue-500 focus:outline-none",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "CRITICAL",
                                            children: "Critical"
                                        }, void 0, false, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 209,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "HIGH",
                                            children: "High"
                                        }, void 0, false, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 210,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "LOW",
                                            children: "Low"
                                        }, void 0, false, {
                                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                            lineNumber: 211,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 203,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                            lineNumber: 201,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-300",
                                    children: "Document Type"
                                }, void 0, false, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 216,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    "data-testid": "add-vendor-doc-type",
                                    value: documentType,
                                    onChange: (event)=>{
                                        setDocumentType(event.target.value);
                                        setGhostFields((current)=>({
                                                ...current,
                                                documentType: false
                                            }));
                                    },
                                    className: `h-8 w-full rounded border border-slate-800 px-3 text-[10px] uppercase text-white focus:border-blue-500 focus:outline-none ${ghostFields.documentType ? "bg-blue-500/10" : "bg-slate-950"}`
                                }, void 0, false, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 217,
                                    columnNumber: 13
                                }, this),
                                ghostFields.documentType && fieldConfidence.documentType !== undefined ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-1 text-[9px] text-blue-200",
                                    children: [
                                        Math.round(fieldConfidence.documentType * 100),
                                        "% Confident"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 229,
                                    columnNumber: 15
                                }, this) : null
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                            lineNumber: 215,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "mb-1 block text-[10px] font-bold uppercase tracking-wide text-slate-300",
                                    children: "Expiration"
                                }, void 0, false, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 234,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    "data-testid": "add-vendor-expiration",
                                    value: expirationDate,
                                    onChange: (event)=>{
                                        setExpirationDate(event.target.value);
                                        setGhostFields((current)=>({
                                                ...current,
                                                expirationDate: false
                                            }));
                                    },
                                    placeholder: "YYYY-MM-DD",
                                    className: `h-8 w-full rounded border border-slate-800 px-3 text-[10px] text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-none ${ghostFields.expirationDate ? "bg-blue-500/10" : "bg-slate-950"}`
                                }, void 0, false, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 235,
                                    columnNumber: 13
                                }, this),
                                ghostFields.expirationDate && fieldConfidence.expirationDate !== undefined ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-1 text-[9px] text-blue-200",
                                    children: [
                                        Math.round(fieldConfidence.expirationDate * 100),
                                        "% Confident"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                                    lineNumber: 248,
                                    columnNumber: 15
                                }, this) : null
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                            lineNumber: 233,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: handleSubmit,
                            disabled: !canSubmit,
                            className: "inline-flex h-8 items-center rounded border border-blue-500/70 bg-blue-500/20 px-3 text-[10px] font-bold uppercase tracking-wide text-blue-200 disabled:opacity-50",
                            children: "Save Vendor"
                        }, void 0, false, {
                            fileName: "[project]/app/vendors/AddVendorModal.tsx",
                            lineNumber: 252,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/vendors/AddVendorModal.tsx",
                    lineNumber: 123,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/vendors/AddVendorModal.tsx",
            lineNumber: 111,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/vendors/AddVendorModal.tsx",
        lineNumber: 110,
        columnNumber: 5
    }, this);
}
_s(AddVendorModal, "shzTTqs2EqDvN5yxzrxarX0uRX0=");
_c = AddVendorModal;
var _c;
__turbopack_context__.k.register(_c, "AddVendorModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/vendors/RFITemplate.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RFITemplate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function RFITemplate({ isOpen, vendorName, vendorEmail, internalStakeholderEmail, checklistItems, onClose, onGenerate }) {
    _s();
    const [selected, setSelected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RFITemplate.useEffect": ()=>{
            if (checklistItems.length === 0) {
                queueMicrotask({
                    "RFITemplate.useEffect": ()=>{
                        setSelected({});
                    }
                }["RFITemplate.useEffect"]);
                return;
            }
            queueMicrotask({
                "RFITemplate.useEffect": ()=>{
                    setSelected(checklistItems.reduce({
                        "RFITemplate.useEffect": (acc, item, index)=>{
                            acc[item] = index === 0;
                            return acc;
                        }
                    }["RFITemplate.useEffect"], {}));
                }
            }["RFITemplate.useEffect"]);
        }
    }["RFITemplate.useEffect"], [
        checklistItems
    ]);
    const selectedItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "RFITemplate.useMemo[selectedItems]": ()=>checklistItems.filter({
                "RFITemplate.useMemo[selectedItems]": (item)=>Boolean(selected[item])
            }["RFITemplate.useMemo[selectedItems]"])
    }["RFITemplate.useMemo[selectedItems]"], [
        checklistItems,
        selected
    ]);
    if (!isOpen) {
        return null;
    }
    const handleGenerate = ()=>{
        const subject = `General RFI Request // ${vendorName}`;
        const body = [
            `Vendor Name: ${vendorName}`,
            "Request Type: General RFI",
            `Requested Items: ${selectedItems.join(", ") || "No items selected"}`,
            "Please provide the requested items in your next response window."
        ].join("\n");
        const mailto = `mailto:${encodeURIComponent(vendorEmail)}?cc=${encodeURIComponent(internalStakeholderEmail)}&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        window.open(mailto, "_blank");
        onGenerate({
            selectedItems
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[90] flex items-center justify-center bg-slate-950/70",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-md rounded border border-slate-800 bg-slate-900 p-4 shadow-2xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-3 flex items-center justify-between border-b border-slate-800 pb-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-[11px] font-bold uppercase tracking-wide text-white",
                            children: "General RFI"
                        }, void 0, false, {
                            fileName: "[project]/app/vendors/RFITemplate.tsx",
                            lineNumber: 71,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: onClose,
                            className: "rounded border border-slate-700 bg-slate-950 px-2 py-1 text-[10px] font-bold uppercase text-slate-300",
                            children: "Close"
                        }, void 0, false, {
                            fileName: "[project]/app/vendors/RFITemplate.tsx",
                            lineNumber: 72,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/vendors/RFITemplate.tsx",
                    lineNumber: 70,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-2",
                    children: checklistItems.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "flex items-center gap-2 text-[10px] text-slate-200",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "checkbox",
                                    checked: Boolean(selected[item]),
                                    onChange: (event)=>setSelected((current)=>({
                                                ...current,
                                                [item]: event.target.checked
                                            }))
                                }, void 0, false, {
                                    fileName: "[project]/app/vendors/RFITemplate.tsx",
                                    lineNumber: 84,
                                    columnNumber: 15
                                }, this),
                                item
                            ]
                        }, item, true, {
                            fileName: "[project]/app/vendors/RFITemplate.tsx",
                            lineNumber: 83,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/app/vendors/RFITemplate.tsx",
                    lineNumber: 81,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    onClick: handleGenerate,
                    className: "mt-4 inline-flex h-8 items-center rounded border border-blue-500/70 bg-blue-500/20 px-3 text-[10px] font-bold uppercase tracking-wide text-blue-200",
                    children: "Generate RFI Draft"
                }, void 0, false, {
                    fileName: "[project]/app/vendors/RFITemplate.tsx",
                    lineNumber: 94,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/vendors/RFITemplate.tsx",
            lineNumber: 69,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/vendors/RFITemplate.tsx",
        lineNumber: 68,
        columnNumber: 5
    }, this);
}
_s(RFITemplate, "1CM1VlgQE9hvjQCVznwvKcKd2tA=");
_c = RFITemplate;
var _c;
__turbopack_context__.k.register(_c, "RFITemplate");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/vendors/Visualizer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Visualizer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const ForceGraph2D = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/node_modules/react-force-graph-2d/dist/react-force-graph-2d.mjs [app-client] (ecmascript, next/dynamic entry, async loader)").then((module)=>module.default), {
    loadableGenerated: {
        modules: [
            "[project]/node_modules/react-force-graph-2d/dist/react-force-graph-2d.mjs [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = ForceGraph2D;
const SERVICE_COORDS = {
    finance: {
        x: -40,
        y: -15
    },
    it: {
        x: 40,
        y: 15
    }
};
function mapVendorToService(vendor) {
    if (vendor.industry === "Finance" || vendor.associatedEntity === "VAULTBANK") {
        return "service-finance";
    }
    return "service-it";
}
function getLinkColor(riskTier) {
    if (riskTier === "LOW") {
        return "rgba(52, 211, 153, 0.85)";
    }
    return riskTier === "CRITICAL" ? "rgba(239, 68, 68, 0.95)" : "rgba(248, 113, 113, 0.9)";
}
function getNodeRadiusByGrade(grade) {
    if (!grade) {
        return 8;
    }
    if (grade === "A") return 7;
    if (grade === "B") return 8;
    if (grade === "C") return 9;
    if (grade === "D") return 11;
    return 13;
}
function Visualizer({ vendors, selectedVendorId, activeVendorIds, onSelectVendor }) {
    _s();
    const graph = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Visualizer.useMemo[graph]": ()=>{
            const serviceNodes = [
                {
                    id: "service-finance",
                    label: "Finance Service",
                    type: "service",
                    fx: SERVICE_COORDS.finance.x,
                    fy: SERVICE_COORDS.finance.y
                },
                {
                    id: "service-it",
                    label: "IT Service",
                    type: "service",
                    fx: SERVICE_COORDS.it.x,
                    fy: SERVICE_COORDS.it.y
                }
            ];
            const vendorNodes = vendors.map({
                "Visualizer.useMemo[graph].vendorNodes": (vendor, index)=>{
                    const angle = 2 * Math.PI * index / Math.max(vendors.length, 1);
                    const radius = 220;
                    return {
                        id: `vendor-${vendor.vendorId}`,
                        label: vendor.vendorName,
                        type: "vendor",
                        riskTier: vendor.cascadedRiskTier,
                        grade: vendor.healthScore.grade,
                        x: Math.cos(angle) * radius,
                        y: Math.sin(angle) * radius
                    };
                }
            }["Visualizer.useMemo[graph].vendorNodes"]);
            const links = vendors.map({
                "Visualizer.useMemo[graph].links": (vendor)=>({
                        source: `vendor-${vendor.vendorId}`,
                        target: mapVendorToService(vendor),
                        riskTier: vendor.cascadedRiskTier
                    })
            }["Visualizer.useMemo[graph].links"]);
            return {
                nodes: [
                    ...serviceNodes,
                    ...vendorNodes
                ],
                links
            };
        }
    }["Visualizer.useMemo[graph]"], [
        vendors
    ]);
    const highRiskRoutes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Visualizer.useMemo[highRiskRoutes]": ()=>vendors.filter({
                "Visualizer.useMemo[highRiskRoutes]": (vendor)=>vendor.cascadedRiskTier !== "LOW"
            }["Visualizer.useMemo[highRiskRoutes]"]).map({
                "Visualizer.useMemo[highRiskRoutes]": (vendor)=>({
                        vendorName: vendor.vendorName,
                        serviceName: mapVendorToService(vendor) === "service-finance" ? "Finance Service" : "IT Service"
                    })
            }["Visualizer.useMemo[highRiskRoutes]"])
    }["Visualizer.useMemo[highRiskRoutes]"], [
        vendors
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "rounded border border-slate-800 bg-slate-950/50 p-3 pt-10",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mb-2 text-[10px] font-bold uppercase tracking-wide text-slate-300",
                children: "Blast Radius // Vendor to Internal Service Map"
            }, void 0, false, {
                fileName: "[project]/app/vendors/Visualizer.tsx",
                lineNumber: 141,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mb-3 text-[9px] uppercase tracking-wide text-slate-400",
                children: "High/Critical links pulse red • Low links stay green • Click vendor node for history/actions"
            }, void 0, false, {
                fileName: "[project]/app/vendors/Visualizer.tsx",
                lineNumber: 142,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-[480px] overflow-hidden rounded border border-slate-800 bg-slate-950",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ForceGraph2D, {
                    graphData: graph,
                    width: 920,
                    height: 480,
                    cooldownTicks: 120,
                    nodeCanvasObject: (node, ctx, globalScale)=>{
                        const graphNode = node;
                        const label = graphNode.label;
                        const fontSize = 11 / globalScale;
                        const isService = graphNode.type === "service";
                        const isSelected = graphNode.id === `vendor-${selectedVendorId}`;
                        const vendorId = graphNode.id.replace("vendor-", "");
                        const isActiveNotification = graphNode.type === "vendor" && activeVendorIds.includes(vendorId);
                        const nodeRadius = isService ? 12 : getNodeRadiusByGrade(graphNode.grade);
                        const isLowGrade = graphNode.grade === "D" || graphNode.grade === "F";
                        const pulseRadius = graphNode.riskTier && graphNode.riskTier !== "LOW" ? 14 + Math.abs(Math.sin(Date.now() / 260)) * 6 : 0;
                        if (pulseRadius > 0 && graphNode.x && graphNode.y) {
                            ctx.beginPath();
                            ctx.arc(graphNode.x, graphNode.y, pulseRadius, 0, 2 * Math.PI, false);
                            ctx.fillStyle = "rgba(248, 113, 113, 0.16)";
                            ctx.fill();
                        }
                        if (isActiveNotification && graphNode.x && graphNode.y) {
                            const activePulseRadius = 16 + Math.abs(Math.sin(Date.now() / 230)) * 7;
                            ctx.beginPath();
                            ctx.arc(graphNode.x, graphNode.y, activePulseRadius, 0, 2 * Math.PI, false);
                            ctx.fillStyle = "rgba(248, 113, 113, 0.22)";
                            ctx.fill();
                        }
                        if (isLowGrade && graphNode.x && graphNode.y) {
                            const lowGradePulse = nodeRadius + 9 + Math.abs(Math.sin(Date.now() / 200)) * 7;
                            ctx.beginPath();
                            ctx.arc(graphNode.x, graphNode.y, lowGradePulse, 0, 2 * Math.PI, false);
                            ctx.fillStyle = "rgba(248, 113, 113, 0.2)";
                            ctx.fill();
                        }
                        ctx.beginPath();
                        ctx.arc(node.x ?? 0, node.y ?? 0, nodeRadius, 0, 2 * Math.PI, false);
                        ctx.fillStyle = isService ? "rgba(59, 130, 246, 0.85)" : graphNode.riskTier === "LOW" ? "rgba(52, 211, 153, 0.95)" : "rgba(248, 113, 113, 0.95)";
                        ctx.fill();
                        if (isSelected || isActiveNotification) {
                            ctx.lineWidth = 2;
                            ctx.strokeStyle = isActiveNotification ? "rgba(248, 113, 113, 0.95)" : "rgba(191, 219, 254, 0.95)";
                            ctx.stroke();
                        }
                        ctx.font = `${fontSize}px Sans-Serif`;
                        ctx.textAlign = "center";
                        ctx.textBaseline = "top";
                        ctx.fillStyle = "#e2e8f0";
                        ctx.fillText(label, node.x ?? 0, (node.y ?? 0) + 12);
                    },
                    linkColor: (link)=>getLinkColor(link.riskTier),
                    linkWidth: (link)=>link.riskTier === "LOW" ? 1.8 : 2.8,
                    linkDirectionalParticles: (link)=>link.riskTier === "LOW" ? 0 : 4,
                    linkDirectionalParticleWidth: (link)=>link.riskTier === "CRITICAL" ? 3 : 2,
                    linkDirectionalParticleSpeed: (link)=>link.riskTier === "CRITICAL" ? 0.014 : 0.009,
                    onNodeClick: (node)=>{
                        const graphNode = node;
                        if (graphNode.type !== "vendor") {
                            return;
                        }
                        onSelectVendor(graphNode.id.replace("vendor-", ""));
                    }
                }, void 0, false, {
                    fileName: "[project]/app/vendors/Visualizer.tsx",
                    lineNumber: 144,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/vendors/Visualizer.tsx",
                lineNumber: 143,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2 rounded border border-slate-800 bg-slate-900/40 px-2 py-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mb-1 text-[9px] font-bold uppercase tracking-wide text-slate-400",
                        children: "High Risk Pulse Routes"
                    }, void 0, false, {
                        fileName: "[project]/app/vendors/Visualizer.tsx",
                        lineNumber: 225,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap gap-1",
                        children: highRiskRoutes.map((route)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "rounded border border-red-500/50 bg-red-500/10 px-2 py-1 text-[9px] uppercase tracking-wide text-red-200",
                                children: [
                                    route.vendorName,
                                    " → ",
                                    route.serviceName
                                ]
                            }, `${route.vendorName}-${route.serviceName}`, true, {
                                fileName: "[project]/app/vendors/Visualizer.tsx",
                                lineNumber: 228,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/vendors/Visualizer.tsx",
                        lineNumber: 226,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/vendors/Visualizer.tsx",
                lineNumber: 224,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/vendors/Visualizer.tsx",
        lineNumber: 140,
        columnNumber: 5
    }, this);
}
_s(Visualizer, "pzMxCiyGW9dO5PJQQRZA5xyTA3U=");
_c1 = Visualizer;
var _c, _c1;
__turbopack_context__.k.register(_c, "ForceGraph2D");
__turbopack_context__.k.register(_c1, "Visualizer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/vendors/ScorecardIcon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ScorecardIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Shield$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shield.js [app-client] (ecmascript) <export default as Shield>");
"use client";
;
;
function ScorecardIcon({ grade, className, onClick }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        onClick: onClick,
        className: `relative flex h-[18px] w-[18px] items-center justify-center ${className}`,
        "aria-label": `Vendor grade ${grade}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Shield$3e$__["Shield"], {
                "data-testid": "scorecard-shield",
                className: "absolute h-[18px] w-[18px] fill-current opacity-25 stroke-[1.8]"
            }, void 0, false, {
                fileName: "[project]/app/vendors/ScorecardIcon.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "relative text-[11px] font-black leading-none",
                children: grade
            }, void 0, false, {
                fileName: "[project]/app/vendors/ScorecardIcon.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/vendors/ScorecardIcon.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = ScorecardIcon;
var _c;
__turbopack_context__.k.register(_c, "ScorecardIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/vendors/RiskSparkbar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RiskSparkbar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const BAR_TONE_CLASS = {
    improved: "bg-emerald-400",
    declined: "bg-red-400",
    neutral: "bg-slate-500"
};
const LABEL_TONE_CLASS = {
    improved: "text-emerald-300",
    declined: "text-red-300",
    neutral: "text-slate-400"
};
const MIN_HEIGHT = 5;
const MAX_HEIGHT = 16;
function RiskSparkbar({ trendPoints, statusLabel, className, ...props }) {
    const source = trendPoints.length >= 5 ? trendPoints.slice(-5) : [
        ...trendPoints
    ];
    while(source.length < 5){
        source.unshift(source[0] ?? 50);
    }
    const max = Math.max(...source, 1);
    const min = Math.min(...source, 0);
    const span = Math.max(max - min, 1);
    const bars = source.map((value, index)=>{
        const prior = index === 0 ? source[index] : source[index - 1];
        const delta = value - prior;
        const tone = delta > 0 ? "improved" : delta < 0 ? "declined" : "neutral";
        const normalized = (value - min) / span;
        const height = Math.round(MIN_HEIGHT + normalized * (MAX_HEIGHT - MIN_HEIGHT));
        return {
            key: `risk-bar-${index}-${value}`,
            height,
            tone
        };
    });
    const latestTone = bars[bars.length - 1]?.tone ?? "neutral";
    const resolvedStatusLabel = statusLabel && statusLabel.trim().length > 0 ? statusLabel : "Status Stable";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `flex shrink-0 flex-col items-center gap-0.5 ${className ?? ""}`.trim(),
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex h-4 items-end gap-0.5",
                "aria-hidden": "true",
                children: bars.map((bar)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `block w-1 rounded-[2px] ${BAR_TONE_CLASS[bar.tone]}`,
                        style: {
                            height: `${bar.height}px`
                        }
                    }, bar.key, false, {
                        fileName: "[project]/app/vendors/RiskSparkbar.tsx",
                        lineNumber: 59,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/vendors/RiskSparkbar.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: `max-w-[110px] text-center text-[10px] font-bold uppercase leading-none tracking-tight ${LABEL_TONE_CLASS[latestTone]}`,
                children: [
                    "Recently Alight // ",
                    resolvedStatusLabel
                ]
            }, void 0, true, {
                fileName: "[project]/app/vendors/RiskSparkbar.tsx",
                lineNumber: 66,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/vendors/RiskSparkbar.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
}
_c = RiskSparkbar;
var _c;
__turbopack_context__.k.register(_c, "RiskSparkbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/services/weeklySummaryService.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getWeeklySummaryMetrics",
    ()=>getWeeklySummaryMetrics,
    "incrementArchivedLowPriority",
    ()=>incrementArchivedLowPriority,
    "incrementRemediatedHighRisk",
    ()=>incrementRemediatedHighRisk
]);
"use client";
const STORAGE_KEY = "weekly-grc-summary-v1";
const DEFAULT_METRICS = {
    archivedLowPriority: 0,
    remediatedHighRisk: 0
};
function readMetrics() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const raw = window.localStorage.getItem(STORAGE_KEY);
        if (!raw) {
            return DEFAULT_METRICS;
        }
        const parsed = JSON.parse(raw);
        return {
            archivedLowPriority: parsed.archivedLowPriority ?? 0,
            remediatedHighRisk: parsed.remediatedHighRisk ?? 0
        };
    } catch  {
        return DEFAULT_METRICS;
    }
}
function writeMetrics(metrics) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(metrics));
}
function getWeeklySummaryMetrics() {
    return readMetrics();
}
function incrementArchivedLowPriority(count) {
    if (count <= 0) {
        return readMetrics();
    }
    const current = readMetrics();
    const next = {
        ...current,
        archivedLowPriority: current.archivedLowPriority + count
    };
    writeMetrics(next);
    return next;
}
function incrementRemediatedHighRisk(count = 1) {
    if (count <= 0) {
        return readMetrics();
    }
    const current = readMetrics();
    const next = {
        ...current,
        remediatedHighRisk: current.remediatedHighRisk + count
    };
    writeMetrics(next);
    return next;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/vendors/schema.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MASTER_VENDORS",
    ()=>MASTER_VENDORS,
    "getDaysUntilExpiration",
    ()=>getDaysUntilExpiration,
    "resolveCadenceStatus",
    ()=>resolveCadenceStatus
]);
const DAY_MS = 24 * 60 * 60 * 1000;
function isoDaysFromNow(days) {
    return new Date(Date.now() + days * DAY_MS).toISOString();
}
function getDaysUntilExpiration(documentExpirationDate, nowMs = Date.now()) {
    const expirationMs = new Date(documentExpirationDate).getTime();
    if (Number.isNaN(expirationMs)) {
        return -1;
    }
    return Math.ceil((expirationMs - nowMs) / DAY_MS);
}
function resolveCadenceStatus(daysUntilExpiration) {
    if (daysUntilExpiration <= 0) {
        return "OVERDUE";
    }
    if (daysUntilExpiration <= 30) {
        return "30";
    }
    if (daysUntilExpiration <= 60) {
        return "60";
    }
    return "90";
}
const MASTER_VENDORS = [
    {
        vendorName: "Azure Health",
        associatedEntity: "MEDSHIELD",
        industry: "Healthcare",
        riskTier: "HIGH",
        securityRating: "84/100",
        contractStatus: "VIOLATION DETECTED",
        documentExpirationDate: isoDaysFromNow(72),
        lastRequestSent: null,
        currentCadence: "90",
        criticalSubProcessors: [
            {
                name: "MediTransit CDN",
                status: "SECURE"
            },
            {
                name: "KubeOps EU-West",
                status: "BREACH"
            }
        ]
    },
    {
        vendorName: "Stripe",
        associatedEntity: "VAULTBANK",
        industry: "Finance",
        riskTier: "HIGH",
        securityRating: "85/100",
        contractStatus: "HEIGHTENED OVERSIGHT",
        documentExpirationDate: isoDaysFromNow(42),
        lastRequestSent: null,
        currentCadence: "60",
        criticalSubProcessors: [
            {
                name: "Payment Gateway Relay",
                status: "SECURE"
            },
            {
                name: "Card Network Bridge",
                status: "SECURE"
            }
        ]
    },
    {
        vendorName: "SWIFT",
        associatedEntity: "VAULTBANK",
        industry: "Finance",
        riskTier: "CRITICAL",
        securityRating: "79/100",
        contractStatus: "HEIGHTENED OVERSIGHT",
        documentExpirationDate: isoDaysFromNow(66),
        lastRequestSent: null,
        currentCadence: "90",
        criticalSubProcessors: [
            {
                name: "InterBank Relay-9",
                status: "SECURE"
            },
            {
                name: "LatencyMesh Core",
                status: "SECURE"
            }
        ]
    },
    {
        vendorName: "Schneider Electric",
        associatedEntity: "GRIDCORE",
        industry: "Energy",
        riskTier: "HIGH",
        securityRating: "88/100",
        contractStatus: "VIOLATION DETECTED",
        documentExpirationDate: isoDaysFromNow(58),
        lastRequestSent: null,
        currentCadence: "60",
        criticalSubProcessors: [
            {
                name: "GridSensor Fabric",
                status: "BREACH"
            },
            {
                name: "OT Firmware Vault",
                status: "SECURE"
            }
        ]
    },
    {
        vendorName: "GCP Cloud",
        associatedEntity: "MEDSHIELD",
        industry: "Healthcare",
        riskTier: "LOW",
        securityRating: "93/100",
        contractStatus: "COMPLIANT",
        documentExpirationDate: isoDaysFromNow(110),
        lastRequestSent: null,
        currentCadence: "90",
        criticalSubProcessors: [
            {
                name: "GCP Logging Layer",
                status: "SECURE"
            },
            {
                name: "Identity Edge Proxy",
                status: "SECURE"
            }
        ]
    },
    {
        vendorName: "Twilio",
        associatedEntity: "VAULTBANK",
        industry: "Finance",
        riskTier: "HIGH",
        securityRating: "86/100",
        contractStatus: "DUE DILIGENCE REQUIRED",
        documentExpirationDate: isoDaysFromNow(95),
        lastRequestSent: null,
        currentCadence: "90",
        criticalSubProcessors: [
            {
                name: "VoiceRoute Exchange",
                status: "SECURE"
            },
            {
                name: "Messaging Queue South",
                status: "SECURE"
            }
        ]
    },
    {
        vendorName: "Crowdstrike",
        associatedEntity: "GRIDCORE",
        industry: "Energy",
        riskTier: "LOW",
        securityRating: "95/100",
        contractStatus: "COMPLIANT",
        documentExpirationDate: isoDaysFromNow(44),
        lastRequestSent: null,
        currentCadence: "60",
        criticalSubProcessors: [
            {
                name: "ThreatGraph Edge",
                status: "SECURE"
            },
            {
                name: "Signature Delta Cache",
                status: "SECURE"
            }
        ]
    },
    {
        vendorName: "ServiceNow",
        associatedEntity: "MEDSHIELD",
        industry: "Healthcare",
        riskTier: "LOW",
        securityRating: "90/100",
        contractStatus: "CONTRACT MONITORED",
        documentExpirationDate: isoDaysFromNow(84),
        lastRequestSent: null,
        currentCadence: "90",
        criticalSubProcessors: [
            {
                name: "Workflow Runtime",
                status: "SECURE"
            },
            {
                name: "Process Ledger",
                status: "SECURE"
            }
        ]
    },
    {
        vendorName: "Palo Alto Networks",
        associatedEntity: "VAULTBANK",
        industry: "Finance",
        riskTier: "CRITICAL",
        securityRating: "82/100",
        contractStatus: "VIOLATION DETECTED",
        documentExpirationDate: isoDaysFromNow(37),
        lastRequestSent: null,
        currentCadence: "60",
        criticalSubProcessors: [
            {
                name: "Packet Shield Mesh",
                status: "SECURE"
            },
            {
                name: "Identity Signature Broker",
                status: "SECURE"
            }
        ]
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/utils/scoringEngine.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateVendorGrade",
    ()=>calculateVendorGrade
]);
function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}
function toGrade(score) {
    if (score >= 90) return "A";
    if (score >= 80) return "B";
    if (score >= 70) return "C";
    if (score >= 60) return "D";
    return "F";
}
function normalizeDocs(docs) {
    return new Set(docs.map((doc)=>doc.trim().toUpperCase()));
}
function calculateVendorGrade(input) {
    const breakdown = [];
    const normalizedDocs = normalizeDocs(input.evidenceLockerDocs);
    let docsScore = 50;
    let industryScore = 30;
    let internalScore = 20;
    const hasSoc2 = normalizedDocs.has("SOC2");
    const hasIso = normalizedDocs.has("ISO") || normalizedDocs.has("ISO 27001");
    const hasInsurance = normalizedDocs.has("INSURANCE");
    const isSoc2Expired = input.daysUntilSoc2Expiration <= 0;
    if (!hasSoc2) {
        docsScore -= 25;
        breakdown.push("SOC2 missing: -25 (Docs)");
    }
    if (isSoc2Expired) {
        docsScore -= 30;
        breakdown.push("SOC2 expired: -30 (Docs)");
    }
    if (!hasIso) {
        docsScore -= 12;
        breakdown.push("ISO missing: -12 (Docs)");
    }
    if (!hasInsurance) {
        docsScore -= 13;
        breakdown.push("Insurance missing: -13 (Docs)");
    }
    if (input.hasActiveBreachAlert) {
        industryScore -= 30;
        breakdown.push("Active industry breach alert: -30 (Industry)");
    } else if (input.hasActiveIndustryAlert) {
        industryScore -= 15;
        breakdown.push("Recent harvester alert(s): -15 (Industry)");
    }
    if (input.requiresManualReview) {
        internalScore -= 10;
        breakdown.push("Manual review required: -10 (Internal)");
    }
    if (input.hasPendingVersioning) {
        internalScore -= 6;
        breakdown.push("Pending version/signature: -6 (Internal)");
    }
    if (input.hasStakeholderEscalation) {
        internalScore -= 4;
        breakdown.push("Stakeholder escalation open: -4 (Internal)");
    }
    docsScore = clamp(docsScore, 0, 50);
    industryScore = clamp(industryScore, 0, 30);
    internalScore = clamp(internalScore, 0, 20);
    let totalScore = docsScore + industryScore + internalScore;
    if (isSoc2Expired) {
        totalScore = Math.min(totalScore, 65);
    }
    if (input.hasActiveBreachAlert) {
        totalScore = Math.min(totalScore, 55);
    }
    const finalScore = clamp(totalScore, 0, 100);
    const grade = toGrade(finalScore);
    return {
        score: finalScore,
        grade,
        breakdown: breakdown.length > 0 ? breakdown : [
            "SOC2/ISO/Insurance current, no industry alerts, and no internal review penalties"
        ]
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/vendors/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VendorsOverviewPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2d$vertical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoreVertical$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/ellipsis-vertical.js [app-client] (ecmascript) <export default as MoreVertical>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
// SaaS Components & Utils
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$NotificationHub$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/NotificationHub.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/auditLogger.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useVendorActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useVendorActions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$systemConfigStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/systemConfigStore.ts [app-client] (ecmascript)");
// Vendor Components
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$vendors$2f$AddVendorModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/vendors/AddVendorModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$vendors$2f$RFITemplate$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/vendors/RFITemplate.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$vendors$2f$Visualizer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/vendors/Visualizer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$vendors$2f$ScorecardIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/vendors/ScorecardIcon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$vendors$2f$RiskSparkbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/vendors/RiskSparkbar.tsx [app-client] (ecmascript)");
// Services
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$weeklySummaryService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/weeklySummaryService.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$vendors$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/vendors/schema.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$scoringEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/scoringEngine.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const RISK_TIER_STYLE = {
    CRITICAL: "text-red-300",
    HIGH: "text-amber-500",
    LOW: "text-emerald-300"
};
const GRADE_BADGE_STYLE = {
    A: "border-emerald-400/80 bg-emerald-500/15 text-emerald-300",
    B: "border-amber-400/80 bg-amber-500/15 text-amber-200",
    C: "border-amber-400/80 bg-amber-500/15 text-amber-200",
    D: "border-red-400/80 bg-red-500/15 text-red-300",
    F: "border-red-400/80 bg-red-500/15 text-red-300"
};
function VendorsOverviewPage() {
    _s();
    const [isMounted, setIsMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const systemConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$systemConfigStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSystemConfigStore"])();
    const [vendors, setVendors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$vendors$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MASTER_VENDORS"]);
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [view, setView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("TABLE");
    const [isAddVendorModalOpen, setIsAddVendorModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [rfiTarget, setRfiTarget] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const { resolveInternalStakeholderEmail } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useVendorActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVendorActions"])(systemConfig.companyStakeholders, systemConfig.vendorTypeRequirements);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VendorsOverviewPage.useEffect": ()=>{
            setIsMounted(true);
        }
    }["VendorsOverviewPage.useEffect"], []);
    const handleEmailVendor = (vendor)=>{
        const internalEmail = resolveInternalStakeholderEmail(vendor.associatedEntity);
        const subject = `Security Evidence Request: ${vendor.vendorName}`;
        const body = `Hello ${vendor.vendorName} team,\n\nPlease provide updated SOC2 documentation.`;
        window.open(`mailto:support@${vendor.vendorName.toLowerCase().replace(/\s+/g, '-')}.local?cc=${internalEmail}&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, "_blank");
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$auditLogger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendAuditLog"])({
            action: "EMAIL_SENT",
            entity: "VENDOR",
            details: `Outreach initiated for ${vendor.vendorName}`,
            timestamp: new Date().toISOString()
        });
    };
    const vendorGraph = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "VendorsOverviewPage.useMemo[vendorGraph]": ()=>{
            if (!isMounted) return [];
            return vendors.filter({
                "VendorsOverviewPage.useMemo[vendorGraph]": (v)=>v.vendorName.toLowerCase().includes(search.toLowerCase())
            }["VendorsOverviewPage.useMemo[vendorGraph]"]).map({
                "VendorsOverviewPage.useMemo[vendorGraph]": (v)=>{
                    const days = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$vendors$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDaysUntilExpiration"])(v.documentExpirationDate);
                    return {
                        ...v,
                        vendorId: v.vendorName.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
                        daysUntilExpiration: days,
                        healthScore: (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$scoringEngine$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateVendorGrade"])({
                            daysUntilSoc2Expiration: days,
                            evidenceLockerDocs: [],
                            hasActiveIndustryAlert: false,
                            hasActiveBreachAlert: false,
                            hasPendingVersioning: false,
                            hasStakeholderEscalation: false,
                            requiresManualReview: false
                        })
                    };
                }
            }["VendorsOverviewPage.useMemo[vendorGraph]"]);
        }
    }["VendorsOverviewPage.useMemo[vendorGraph]"], [
        isMounted,
        vendors,
        search
    ]);
    if (!isMounted) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-full bg-slate-950"
    }, void 0, false, {
        fileName: "[project]/app/vendors/page.tsx",
        lineNumber: 93,
        columnNumber: 26
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-full bg-slate-950 p-6 font-sans",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$NotificationHub$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                alerts: [],
                resolveRiskTier: (name)=>vendors.find((v)=>v.vendorName === name)?.riskTier || "LOW",
                onArchiveLowPriority: (ids)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$weeklySummaryService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["incrementArchivedLowPriority"])(ids.length)
            }, void 0, false, {
                fileName: "[project]/app/vendors/page.tsx",
                lineNumber: 97,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "rounded border border-slate-800 bg-slate-900/40 p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "mb-4 text-[11px] font-bold uppercase tracking-wide text-white",
                        children: "SUPPLY CHAIN // GLOBAL VENDOR INTELLIGENCE"
                    }, void 0, false, {
                        fileName: "[project]/app/vendors/page.tsx",
                        lineNumber: 104,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4 flex items-center gap-2 overflow-x-auto pb-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative w-[260px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                        className: "absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500"
                                    }, void 0, false, {
                                        fileName: "[project]/app/vendors/page.tsx",
                                        lineNumber: 108,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        value: search,
                                        onChange: (e)=>setSearch(e.target.value),
                                        placeholder: "Search...",
                                        className: "bg-slate-950 border border-slate-800 rounded px-4 py-2 text-[11px] text-white pl-9 w-full outline-none"
                                    }, void 0, false, {
                                        fileName: "[project]/app/vendors/page.tsx",
                                        lineNumber: 109,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/vendors/page.tsx",
                                lineNumber: 107,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/reports/audit-trail?scope=vendor-changes",
                                className: "inline-flex h-8 items-center rounded border border-slate-800 bg-slate-950 px-3 text-[10px] font-bold text-slate-300 hover:border-blue-500",
                                children: "Activity Log"
                            }, void 0, false, {
                                fileName: "[project]/app/vendors/page.tsx",
                                lineNumber: 117,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setView(view === "TABLE" ? "MAP" : "TABLE"),
                                className: "h-8 rounded border border-slate-800 bg-slate-950 px-3 text-[10px] font-bold text-slate-300 hover:border-blue-500",
                                children: view === "TABLE" ? "Map View" : "Table View"
                            }, void 0, false, {
                                fileName: "[project]/app/vendors/page.tsx",
                                lineNumber: 121,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/",
                                className: "inline-flex h-8 items-center rounded border border-slate-800 bg-slate-950 px-3 text-[10px] font-bold text-slate-300 hover:border-blue-500 ml-auto",
                                children: "Back"
                            }, void 0, false, {
                                fileName: "[project]/app/vendors/page.tsx",
                                lineNumber: 125,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/vendors/page.tsx",
                        lineNumber: 106,
                        columnNumber: 9
                    }, this),
                    view === "TABLE" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded border border-slate-800 overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-9 border-b border-slate-800 bg-slate-950 px-4 py-2 text-[10px] font-bold uppercase text-slate-300",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: "Scorecard"
                                    }, void 0, false, {
                                        fileName: "[project]/app/vendors/page.tsx",
                                        lineNumber: 133,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: "VENDOR NAME"
                                    }, void 0, false, {
                                        fileName: "[project]/app/vendors/page.tsx",
                                        lineNumber: 134,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: "ENTITY"
                                    }, void 0, false, {
                                        fileName: "[project]/app/vendors/page.tsx",
                                        lineNumber: 135,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: "RISK"
                                    }, void 0, false, {
                                        fileName: "[project]/app/vendors/page.tsx",
                                        lineNumber: 136,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: "RATING"
                                    }, void 0, false, {
                                        fileName: "[project]/app/vendors/page.tsx",
                                        lineNumber: 137,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: "STATUS"
                                    }, void 0, false, {
                                        fileName: "[project]/app/vendors/page.tsx",
                                        lineNumber: 138,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: "COUNTDOWN"
                                    }, void 0, false, {
                                        fileName: "[project]/app/vendors/page.tsx",
                                        lineNumber: 139,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: "LOCKER"
                                    }, void 0, false, {
                                        fileName: "[project]/app/vendors/page.tsx",
                                        lineNumber: 140,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-right",
                                        children: "ACTIONS"
                                    }, void 0, false, {
                                        fileName: "[project]/app/vendors/page.tsx",
                                        lineNumber: 141,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/vendors/page.tsx",
                                lineNumber: 132,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "max-h-[500px] overflow-y-auto p-2 space-y-2",
                                children: vendorGraph.map((vendor)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-9 items-center gap-3 bg-slate-900/40 border border-slate-800 px-4 py-3 text-[11px] hover:border-blue-500/50",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$vendors$2f$ScorecardIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        grade: vendor.healthScore.grade,
                                                        className: GRADE_BADGE_STYLE[vendor.healthScore.grade]
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/vendors/page.tsx",
                                                        lineNumber: 148,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$vendors$2f$RiskSparkbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        trendPoints: [
                                                            40,
                                                            50,
                                                            60
                                                        ],
                                                        statusLabel: "Stable"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/vendors/page.tsx",
                                                        lineNumber: 149,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/vendors/page.tsx",
                                                lineNumber: 147,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "font-semibold text-white",
                                                children: vendor.vendorName
                                            }, void 0, false, {
                                                fileName: "[project]/app/vendors/page.tsx",
                                                lineNumber: 151,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-slate-400",
                                                children: vendor.associatedEntity
                                            }, void 0, false, {
                                                fileName: "[project]/app/vendors/page.tsx",
                                                lineNumber: 152,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: `font-bold ${RISK_TIER_STYLE[vendor.riskTier]}`,
                                                children: vendor.riskTier
                                            }, void 0, false, {
                                                fileName: "[project]/app/vendors/page.tsx",
                                                lineNumber: 153,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: vendor.securityRating
                                            }, void 0, false, {
                                                fileName: "[project]/app/vendors/page.tsx",
                                                lineNumber: 154,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-slate-400",
                                                children: vendor.contractStatus
                                            }, void 0, false, {
                                                fileName: "[project]/app/vendors/page.tsx",
                                                lineNumber: 155,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: `font-bold ${vendor.daysUntilExpiration < 30 ? 'text-red-300' : 'text-emerald-300'}`,
                                                children: vendor.daysUntilExpiration <= 0 ? "EXPIRED" : `${vendor.daysUntilExpiration} DAYS`
                                            }, void 0, false, {
                                                fileName: "[project]/app/vendors/page.tsx",
                                                lineNumber: 156,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex gap-1",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "bg-slate-800 px-1.5 py-0.5 rounded text-[8px] border border-slate-700",
                                                    children: "SOC2"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/vendors/page.tsx",
                                                    lineNumber: 159,
                                                    columnNumber: 47
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/vendors/page.tsx",
                                                lineNumber: 159,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-right",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>handleEmailVendor(vendor),
                                                    className: "p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2d$vertical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoreVertical$3e$__["MoreVertical"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/vendors/page.tsx",
                                                        lineNumber: 161,
                                                        columnNumber: 146
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/vendors/page.tsx",
                                                    lineNumber: 161,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/vendors/page.tsx",
                                                lineNumber: 160,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, vendor.vendorId, true, {
                                        fileName: "[project]/app/vendors/page.tsx",
                                        lineNumber: 146,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/vendors/page.tsx",
                                lineNumber: 144,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/vendors/page.tsx",
                        lineNumber: 131,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$vendors$2f$Visualizer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        vendors: vendorGraph
                    }, void 0, false, {
                        fileName: "[project]/app/vendors/page.tsx",
                        lineNumber: 168,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/vendors/page.tsx",
                lineNumber: 103,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$vendors$2f$AddVendorModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isAddVendorModalOpen,
                onClose: ()=>setIsAddVendorModalOpen(false),
                vendorTypeRequirements: systemConfig.vendorTypeRequirements,
                onSubmit: (data)=>{
                    console.log("New Vendor:", data);
                    setIsAddVendorModalOpen(false);
                }
            }, void 0, false, {
                fileName: "[project]/app/vendors/page.tsx",
                lineNumber: 173,
                columnNumber: 7
            }, this),
            rfiTarget && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$vendors$2f$RFITemplate$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: true,
                vendorName: rfiTarget.vendorName,
                onClose: ()=>setRfiTarget(null),
                onGenerate: ()=>setRfiTarget(null)
            }, void 0, false, {
                fileName: "[project]/app/vendors/page.tsx",
                lineNumber: 184,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/vendors/page.tsx",
        lineNumber: 96,
        columnNumber: 5
    }, this);
}
_s(VendorsOverviewPage, "6MLtmcOz8ku2jDx40rR656p/TCM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$systemConfigStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSystemConfigStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useVendorActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVendorActions"]
    ];
});
_c = VendorsOverviewPage;
var _c;
__turbopack_context__.k.register(_c, "VendorsOverviewPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_90bdced4._.js.map